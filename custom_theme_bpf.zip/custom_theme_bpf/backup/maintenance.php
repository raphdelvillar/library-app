    <?php get_header(); ?>
        <!-- SIDEBAR -->
        <?php get_sidebar(); ?>
        <!-- END OF SIDEBAR -->
        <!-- START OF CONTENT -->
        <div flex-xs="100" flex-sm="100" flex-md="75" flex="75" layout-padding id="main" layout-xs="column" layout-sm="column" layout-md="row" layout="row" style="background-image: url('<?php echo get_template_directory_uri();?>/assets/royal_plaza.jpg'); float: right;">
            <!-- BULLETIN -->
            <div flex-xs="100" flex-sm="100" flex-md="50" flex="50" layout-padding layout="column" id="bulletin_news" style="display:block;">
                <center>
                    <h1>BULLETIN NEWS</h1>
                    <md-button  hide-md hide-gt-md id="toggler" class="md-fab">
                        <i class="material-icons" style="vertical-align:middle">&#xE5DD;</i>
                    </md-button>
                </center>
                <div flex="45" id="bulletin">
                    <md-list> 
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/8.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow"><i class="material-icons" style="vertical-align: middle">&#xE8D0;</i>
                                Online Business Officers - Join Now
                                </h5>
                                <p style="color:white">
                                    For our business operations, we need Immediate freelance team members who<br/><br/>
                                    ... can do online business development <br/>
                                    ... can source business leads of recruitment (workers, staff), outsourcing, websites development, social media advertisement, construction projects, HR  Consultancy, Project Management) <br/>
                                    ... can communicate online to business community through social media <br/>
                                    ... can work on Commission and Incentive basis <br/>
                                    ... can give Freelance Services from their Current jobs <br/><br/>
                                    If you meet the above Criteria, please visit our website, register and drop your portfolio with a recent photo and your expertise skills while applying online <br/><br/>
                                    Commission and Incentive Packages are above your expectations <br/><br/>
                                    Businesspartnersforum.com <br/>
                                    Email.Info@businesspartnersforum.com
                                </p>
                            </div>
                        </md-list-item> 
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/9.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow"><i class="material-icons" style="vertical-align: middle">&#xE8D0;</i>
                                Immediate Hiring: Secretary/Social Media Officer
                                </h5>
                                <p style="color:white">
                                    We immediately need a smart, young and active receptionist who has<br/><br/>
                                    ...Strong Secretarial Exposure<br/>
                                    ...Can manage receptionist role<br/>
                                    ...well versed in social media comminication (fb, twitter, tumblr, instagram etc)<br/>
                                    ...can do Social media marketing through Social blogs<br/>
                                    ...can do business correspondence<br/><br/>
                                    Note: Fresh Graduate can also apply provided they meet the above criteria.
                                </p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider> 
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/0.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">
                                <i class="material-icons" style="vertical-align: middle">&#xE8D0;</i>
                                Joint-Venture partnership on its way. 
                                </h5>
                                <p style="color:white">Another milestone with Envoy holding Sri Lanka to be our Joint-Venture partners</p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/1.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Company Official Launching</h5>
                                <p style="color:white">We are officially opening our doors for business on 15th of August, 2017</p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/2.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Join us Now & Earn Additional...</h5>
                                <p style="color:white">We are hiring Online Business Officers on Commission Basis. Get the business and take more than you expect</p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/3.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Post your Portfolio Now...</h5>
                                <p style="color:white">Hurry Up, Register Now and Post your Resume for Free</p>
                            </div> 
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/4.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Joint-Venture Partners...</h5>
                                <p style="color:white">Explore the Business In Qatar with us as Joint-Venture Partners for Recruitment and Outsourcing</p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/5.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Fabulous Discounts on  Social Media Advertisement...</h5>
                                <p style="color:white">Get 50 % discounts for highly responsive and interactive web sites</p>
                            </div> 
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/6.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Free Social Media Advertisement...</h5>
                                <p style="color:white">Absolutely free media advertisement for 3 months for first 10 Business Subscribers</p>
                            </div>
                        </md-list-item>
                        <md-divider></md-divider>
                        <md-list-item class="md-2-line">
                            <img src="<?php echo get_template_directory_uri();?>/assets/bulletin/7.jpeg" class="md-avatar"/>
                            <div class="md-list-item-text">
                                <h5 style="color:yellow">Your Business Setup Consultants...</h5>
                                <p style="color:white">Turnkey Solutions from Local Sponsorship to Company Establishment in Qatar</p>
                            </div>
                        </md-list-item> 
                    </md-list>
                </div>
                <div flex><br/><br/></div>
                <div flex>
                    <center>
                    <div class="tinycarousel">
                            <div class="viewport" style="margin-left: 5%">
                                <ul class="overview">
                                    <li>
                                        <a data-fancybox="advertisement" href="<?php echo get_template_directory_uri();?>/assets/advertisement/web.jpg" data-caption="">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/advertisement/web.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        </center>
                </div>
                <div flex>
                    <center><h3>Launching Business Operations on 15th of August, 2017</h3></center>
                    <!--
                    <center hide-xs hide-sm style="background-color: black; margin-top: 7.5%"><h2 id="timer1"></h2></center>
                    -->
                    <center hide-md hide-gt-md><h2 id="timer2"></h2></center>
                </div>
            </div>
            <!-- END OF BULLETIN -->
            <!-- OUR BUSINESS PHILOSOPHY -->
            <div flex-xs="100" flex-sm="100" flex-md="50" flex="50" layout-padding layout="column" id="business_philosophy">
                <center style="background-color:#9E1C37">
                    <h1 style="color:white">OUR BUSINESS PHILOSOPHY</h1>
                </center>
                <p style="text-align:justify">
                    Partners Forum Service is a unique business platform to integrate both Business and Service Providers in an Interactive Online platform. It gives one Single Window for Business Community to Interact both as Business Provider or Service Provider.
                    <br/><br/>
                    Our Mission and Objective is to act as Business Partners for all business community from entrepreneurs, multinationals that wish to setup their business operations in Qatar to all service/business providers both International/Qatar based with Technical/Business support in
                </p>
                <p hide-md hide-gt-md style="line-height: 200%">
                    •   Social Media Advertisement
                    <br/>•  Company Formation in Qatar
                    <br/>•  Recruitment 
                    <br/>•  Outsourcing 
                    <br/>•  Web Media
                    <br/>•  Legal Attorneys Panel
                    <br/>•  Business/Project Consultants 
                    <br/>•  JV Partners
                    <br/>•  Construction/FM Consultants
                </p>
                <div hide-xs hide-sm layout="column" style="display: block;">
                    <div flex style="float:left">
                        <p hide-xs hide-sm style="line-height: 200%"><br/>
                            •   Social Media Advertisement
                            <br/>•  Company Formation in Qatar
                            <br/>•  Recruitment 
                            <br/>•  Outsourcing 
                            <br/>•  Web Media
                            <br/>•  Legal Attorneys Panel
                            <br/>•  Business/Project Consultants 
                            <br/>•  JV Partners
                            <br/>•  Construction/FM Consultants
                        </p>
                    </div>
                    <div flex>
                        <!-- START OF COMPANIES ON BOARD international-partners -->
                        <div class="tinycarousel" hide-xs hide-sm>
                            <center><b><u>International Partners</u></b></center><br/>
                            <div class="viewport" style="margin-left: 5%">
                                <ul class="overview">
                                    <li></li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20245467_1899385080310613_3623568213353250812_n.jpg" data-caption="SensorTec">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20245467_1899385080310613_3623568213353250812_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20293082_1899385053643949_6860001621824176817_n.jpg" data-caption="Middle East Foundations Group LLC">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20293082_1899385053643949_6860001621824176817_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374230_1899385136977274_8497896483168899268_n.jpg" data-caption="Hagen Group">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374230_1899385136977274_8497896483168899268_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374253_1899384983643956_4773974955544741493_n.jpg" data-caption="Turner & Townsend">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374253_1899384983643956_4773974955544741493_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374402_1899385063643948_8707098788184306931_n.jpg" data-caption="Parchettificio Toscano">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374402_1899385063643948_8707098788184306931_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20375634_1899385013643953_8025414718192133507_n.jpg" data-caption="ENVISION Global Inc.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20375634_1899385013643953_8025414718192133507_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20430106_1899384993643955_6498388724814987425_n.jpg" data-caption="Econpile">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20430106_1899384993643955_6498388724814987425_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20476137_1899385126977275_3193518496954018250_n.jpg" data-caption="Catic - Qatar">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20476137_1899385126977275_3193518496954018250_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20479434_1899385096977278_4425407421712664712_n.jpg" data-caption="Tilke">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20479434_1899385096977278_4425407421712664712_n.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- END OF COMPANIES ON BOARD international-partners -->
                        <!-- START OF BUSINESS VENTURES -->
                        <div class="tinycarousel" hide-xs hide-sm>
                            <center><b><u>Business Ventures</u></b></center><br/>
                            <div class="viewport" style="margin-left: 5%">
                                <ul class="overview">
                                    <li>

                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv1.jpg" data-caption="With the chairman of Savills- Project Company in Singapore.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv1.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv2.jpg" data-caption="With the CEO's of PTE Tuscano (Italy) Hagen-(Portugal) Catic- (China)in a business conference.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv2.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv3.jpg" data-caption="With the CEO of Strong Force- Australia in a Business meeting.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv3.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv4.jpg" data-caption="With my Business Team member in a contract ceremony with Strong Force Australia.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv4.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv5.jpg" data-caption="In Philipines, while attending a Top Business ceremony.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv5.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv6.jpg" data-caption="CEO of Catic- China signing company establishment papers in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv6.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv7.jpg" data-caption="CEO of Catic (Chinese Company) in a Business conference arranged by PFS.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv7.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv8.jpg" data-caption="Signing Company Establishment contract with the Chairman and CEO of PTE- Tuscano Italy.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv8.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv9.jpg" data-caption="CEO & Chairman of PTE- Tuscano Italy in Company launching ceremony.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv9.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv10.jpg" data-caption="With Group partners in 2011.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv10.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv11.jpg" data-caption="With Directors of Mcnally Design International in 2011.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv11.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv12.jpg" data-caption="With CEO of Sensortec- Canada">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv12.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv13.jpg" data-caption="With CEO's and senior Management members during Project Qatar Exhibition in 2011">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv13.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv14.jpg" data-caption="With CEO of Patton International Ireland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv14.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv15.jpg" data-caption="With CEO of Patton International Ireland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv15.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv16.jpg" data-caption="With CEO and MD of Trust Hospitality USA.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv16.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv17.jpg" data-caption="Signing occassion in 2011 with Mr. Steve- MD of Strong Force Australia to have establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv17.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv18.jpg" data-caption="Signing ceremony in 2010 with Mr. Sherif, Owner and MD of IDDI USA for company establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv18.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv19.jpg" data-caption="Signing business contract with Mr. Jason Morris, owner of Jason Morris for company establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv19.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv20.jpg" data-caption="With Mr. Greham in 2010 during establishment of Bond Bryan (UK based Consultants) in Qatar">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv20.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv21.jpg" data-caption="Signing business contract with Chairman of JP Contracting in Warsaw Poland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv21.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv22.jpg" data-caption="In Singapore with Top officials">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv22.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv23.jpg" data-caption="Meeting in 2011 with owner and MD of Melham- USA for Interior designing business in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv23.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv24.jpg" data-caption="PTE- Tuscano - Italy for company Establishment in Qatar in 2010 with IDDI members as guest.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv24.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <!-- END OF BUSINESS VENTURES -->
                    </div>
                </div>
                <!--
                <div flex hide-xs hide-sm hide-md>
                    <center style="background-color: black; color: white"><h2>Connecting Business...</h2></center>
                </div>
                -->
            </div>
            
            <!-- END OF OUR BUSINESS PHILOSOPHY -->
            <!-- START OF COMPANIES ON BOARD international-partners -->
            <div class="tinycarousel" hide-md hide-gt-md style="background-color: white">
                <center style="background-color:#9E1C37">
                    <h1 style="color:white">International Partners</h1>
                </center>
                    <div class="viewport" style="margin: 0 auto;">
                        <ul class="overview">
                            <li></li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20245467_1899385080310613_3623568213353250812_n.jpg" data-caption="SensorTec">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20245467_1899385080310613_3623568213353250812_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20293082_1899385053643949_6860001621824176817_n.jpg" data-caption="Middle East Foundations Group LLC">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20293082_1899385053643949_6860001621824176817_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374230_1899385136977274_8497896483168899268_n.jpg" data-caption="Hagen Group">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374230_1899385136977274_8497896483168899268_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374253_1899384983643956_4773974955544741493_n.jpg" data-caption="Turner & Townsend">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374253_1899384983643956_4773974955544741493_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374402_1899385063643948_8707098788184306931_n.jpg" data-caption="Parchettificio Toscano">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20374402_1899385063643948_8707098788184306931_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20375634_1899385013643953_8025414718192133507_n.jpg" data-caption="ENVISION Global Inc.">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20375634_1899385013643953_8025414718192133507_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20430106_1899384993643955_6498388724814987425_n.jpg" data-caption="Econpile">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20430106_1899384993643955_6498388724814987425_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20476137_1899385126977275_3193518496954018250_n.jpg" data-caption="Catic - Qatar">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20476137_1899385126977275_3193518496954018250_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                            <li>
                                <a data-fancybox="international-partners" href="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20479434_1899385096977278_4425407421712664712_n.jpg" data-caption="Tilke">
                                <img src="<?php echo get_template_directory_uri();?>/assets/companies-on-board/20479434_1899385096977278_4425407421712664712_n.jpg" style="width:100%;height:auto;"/>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tinycarousel" hide-md hide-gt-md style="background-color: white">
                    <center style="background-color:#9E1C37">
                        <h1 style="color:white">Business Ventures</h1>
                    </center>
                            <div class="viewport" style="margin: 0 auto;">
                                <ul class="overview">
                                    <li>

                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv1.jpg" data-caption="With the chairman of Savills- Project Company in Singapore.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv1.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv2.jpg" data-caption="With the CEO's of PTE Tuscano (Italy) Hagen-(Portugal) Catic- (China)in a business conference.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv2.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv3.jpg" data-caption="With the CEO of Strong Force- Australia in a Business meeting.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv3.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv4.jpg" data-caption="With my Business Team member in a contract ceremony with Strong Force Australia.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv4.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv5.jpg" data-caption="In Philipines, while attending a Top Business ceremony.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv5.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv6.jpg" data-caption="CEO of Catic- China signing company establishment papers in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv6.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv7.jpg" data-caption="CEO of Catic (Chinese Company) in a Business conference arranged by PFS.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv7.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv8.jpg" data-caption="Signing Company Establishment contract with the Chairman and CEO of PTE- Tuscano Italy.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv8.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv9.jpg" data-caption="CEO & Chairman of PTE- Tuscano Italy in Company launching ceremony.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv9.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv10.jpg" data-caption="With Group partners in 2011.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv10.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv11.jpg" data-caption="With Directors of Mcnally Design International in 2011.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv11.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv12.jpg" data-caption="With CEO of Sensortec- Canada">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv12.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv13.jpg" data-caption="With CEO's and senior Management members during Project Qatar Exhibition in 2011">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv13.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv14.jpg" data-caption="With CEO of Patton International Ireland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv14.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv15.jpg" data-caption="With CEO of Patton International Ireland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv15.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv16.jpg" data-caption="With CEO and MD of Trust Hospitality USA.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv16.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv17.jpg" data-caption="Signing occassion in 2011 with Mr. Steve- MD of Strong Force Australia to have establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv17.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv18.jpg" data-caption="Signing ceremony in 2010 with Mr. Sherif, Owner and MD of IDDI USA for company establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv18.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv19.jpg" data-caption="Signing business contract with Mr. Jason Morris, owner of Jason Morris for company establishment in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv19.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv20.jpg" data-caption="With Mr. Greham in 2010 during establishment of Bond Bryan (UK based Consultants) in Qatar">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv20.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv21.jpg" data-caption="Signing business contract with Chairman of JP Contracting in Warsaw Poland.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv21.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv22.jpg" data-caption="In Singapore with Top officials">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv22.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv23.jpg" data-caption="Meeting in 2011 with owner and MD of Melham- USA for Interior designing business in Qatar.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv23.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-fancybox="business-ventures" href="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv24.jpg" data-caption="PTE- Tuscano - Italy for company Establishment in Qatar in 2010 with IDDI members as guest.">
                                        <img src="<?php echo get_template_directory_uri();?>/assets/business-ventures/bv24.jpg" style="width:100%;height:auto;"/>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
        </div>
        <!-- END OF CONTENT -->
    </md-content>

    <!-- COUNTDOWN -->
    <script>
    // Set the date we're counting down to
    var countDownDate = new Date("August 15, 2017").getTime();

    // Update the count down every 1 second
    var x = setInterval(function() {

      // Get todays date and time
      var now = new Date().getTime();

      // Find the distance between now an the count down date
      var distance = countDownDate - now;

      // Time calculations for days, hours, minutes and seconds
      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      // Display the result in the element with id="demo"
      if(document.getElementById("timer1")){
          document.getElementById("timer1").innerHTML = days + "d " + hours + "h "
          + minutes + "m " + seconds + "s ";
      }

      if(document.getElementById("timer2")){
          document.getElementById("timer2").innerHTML = days + "d " + hours + "h "
          + minutes + "m " + seconds + "s ";
      }
      // If the count down is finished, write some text 
      if (distance < 0) {
        clearInterval(x);
        if(document.getElementById("timer1")){
            document.getElementById("timer1").innerHTML = "EXPIRED";
        }

        if(document.getElementById("timer2")){
            document.getElementById("timer2").innerHTML = "EXPIRED";
        }
      }
    }, 1000);
    </script>

    <?php get_footer(); ?>