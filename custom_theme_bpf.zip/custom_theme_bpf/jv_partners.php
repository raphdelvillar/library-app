	<!--/* Template Name: JV_Partners */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/jv_partnerships.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Joint Ventures</h2>
	    	<p align="justify" class="md-body-1">
		    	BPF offers a wide range of Joint Ventures (Business & Service Providers) both for International/Local Partners to strengthen its business arm in Qatar and Middle East.<br/><br/>

				We welcome the <b>International (Consultancy/Contracting)</b> to join us as <b>JV Partners</b> to strengthen our (Design and Build) business arm with 16 International Key Players already as Business Affiliates<br/><br/>

				We welcome also <b>all International recruitment agencies</b> and <b>Head-hunters</b> to join our Interactive recruitment Online Platform as JV Partners with a business model of Business-Service). We will give the business leads and been our JV Partners, you will do the execution part.<br/><br/>

				We also welcome <b>Service Providers</b> from the Local Market to act as our JV Partners for any services that can give value addition to our business clients. 
	    	</p>
	    	</div>

	    	<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Do you have a Business Query? Have an Online Chat with us!</h4>
	    	<h4 hide-gt-md style="color:#72012C">Do you have a Business Query? <br/> Have an Online Chat with us!</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Drop your Business Query</md-button>
				</div>
			</div>
			</div>
	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>