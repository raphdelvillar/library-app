	<!--/* Template Name: Contact_Us */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>
	    	<div layout="column" layout-padding>
                <div layout="row" layout-xs="column" layout-sm="column" layout-align="center center">
                    <div hide-xs hide-sm flex="5"></div>
                	<div flex="45" flex-xs="90" flex-sm="90">
                		<h3 style="color:#72012C">Business Query</h3>	
                		<ul id="contact-form" style="list-style:none;margin:0;padding:0">
						<?php dynamic_sidebar( 'widgetcontactform' ); ?>
						</ul>
                	</div>
                	<div flex="45" flex-xs="90" flex-sm="90" style="border-left:2px solid #72012C">	
                		<center>
                		<ul style="list-style:none;margin:0;padding:0">
						<?php dynamic_sidebar( 'widgetcontactmap' ); ?>
						</ul>
						</center>
                		<br/><br/>
                		<p class="md-body-1" flex-offset="5">
					    	<i class="icon-contact fa-map-marker" style="color:#72012C"></i>
					    	&nbsp;&nbsp;&nbsp;B-ring Road, 7th Floor, Sultan Sultan Building, Al Handasa Street., Najma, Al Mansoura. P.O Box. 3129 , Doha Qatar 
					    </p>
					    <br/>
					    <p class="md-body-1" flex-offset="5">
                			<i class="icon-contact fa-phone" style="color:#72012C"></i>
					    	&nbsp;&nbsp;&nbsp;+974 4498 0376
					    </p>
					    <br/>
					    <p class="md-body-1" flex-offset="5">
	                		<i class="icon-contact fa-envelope-o" style="color:#72012C"></i>
						    &nbsp;&nbsp;&nbsp;Info@businesspartnersforum.com
					    </p>
                	</div>
                	<div hide-xs hide-sm flex="5"></div>
                </div>
	    	</div>

	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>