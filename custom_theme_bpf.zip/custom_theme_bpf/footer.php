<?php wp_footer(); ?>
  <!--
  <div show-md show-gt-md style="background-color: #000000;color: #ffffff;position:fixed;">
    <div layout="row" layout-xs="column" layout-sm="column" flex>
      <div flex="75" flex-xs="100" flex-sm="100">
        <center>

          <marquee loop="true" direction="left" scrollamount="2" class="footer">
            <p style="font-size:75%">
              <img style="vertical-align:middle" src="<?php //echo get_template_directory_uri();?>/assets/qatar-flag.jpg" alt="flag" width="32"/> 
              Together, We Serve Better
            </p>
          </marquee>  

        </center>
      </div>
      <div flex>
        <center>
          <p>&copy businesspartnersforum 2017</p>
        </center>
      </div>
    </div>
  -->
    <!-- Custom Scripts -->
    <script src="<?php echo get_template_directory_uri();?>/custom/init.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/factory.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/directive.js"></script>

    <!-- Recruitment -->
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/recruitment.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/login.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/applicant_registration.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/business_registration.js"></script>

    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/admin.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/contract.js"></script>

    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/registration.js"></script>

    <!-- Views -->
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/applicants.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/freelancers.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/bp.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/recruitment/view/sp.js"></script>

    <!-- Home -->
    <script src="<?php echo get_template_directory_uri();?>/custom/home/masterslider.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/home/tinycarousel.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/custom/home/bulletin.js"></script>

    <!-- About -->
    <script src="<?php echo get_template_directory_uri();?>/custom/about/textrotate.js"></script>

    <!-- MARQUEE -->
    <script>
      $(document).ready(function () {
        $('.tinycarousel').tinycarousel({ interval: true })
      });
    </script>

  </body>
  </html>