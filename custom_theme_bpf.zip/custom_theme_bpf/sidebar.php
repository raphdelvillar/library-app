<div ng-cloak layout="row" layout-xs="column" class="top">
  <center><span style="font-size: 75%"><a style="color:#FFFFFF;padding:5px" href="www.businesspartnersforum.com/contact-us">info@businesspartnersforum.com</a></span></center>
  <div flex></div>
  <div flex-gt-md="25" flex-md="30">
    <center>
    <a href="https://www.facebook.com/businesspartnersforum" target="_blank" class="icon-button facebook">
        <i class="icon-facebook fa-facebook"></i><span></span>
    </a>
    <a href="https://twitter.com/bpfqatar" target="_blank" class="icon-button twitter">
        <i class="icon-twitter fa-twitter"></i><span></span>
    </a>
    <a href="https://www.instagram.com/bpfqatar" target="_blank" class="icon-button instagram">
        <i class="icon-instagram fa-instagram"></i><span></span>
    </a>
    <a href="https://www.linkedin.com/in/business-partners-forum-619b72150" class="icon-button linkedin">
        <i class="icon-linkedin fa-linkedin"></i><span></span>
    </a>
    <!--
    <a href="https://businesspartnersforum.tumblr.com" target="_blank" class="icon-button tumblr">
        <i class="icon-tumblr fa-tumblr"></i><span></span>
    </a>
    -->
    <!--
    <a href="" class="icon-button youtube">
        <i class="icon-youtube fa-youtube-play"></i><span></span>
    </a>
    -->
    <a href="https://join.skype.com/cYJrRpLyQNSo" target="_blank" class="icon-button skype">
        <i class="icon-skype fa-skype"></i><span></span>
    </a>
    </center>
  </div>
</div>
<nav ng-cloak class="md-whiteframe-1dp" layout="row" layout-align="center center" style="height: 75px; background-color: #FFFFFF">
  <div id="primary_nav_wrap" hide-gt-md hide-md>
    <ul>
        <li><a href="#"><i class="material-icons" style="color:#72012C">&#xE8FE;</i></a>
            <ul>
              <li><a href="#">About Us</a>
                <ul>
                  <li><a href="www.businesspartnersforum.com/about-us-business-strategy">Business Strategy</a></li>
                  <li><a href="www.businesspartnersforum.com/about-us-owners-message">Owner's Message</a></li>
                  <li><a href="www.businesspartnersforum.com/about-us-partners-message">Partner's Message</a></li>
                  <!--<li><a href="#">Our Partners</a>-->
                </ul>
              </li>
              <li><a href="#">Business Services</a>
                <ul>
                  <li><a href="www.businesspartnersforum.com/business-services-local-sponsorship">Local Sponsorship</a></li>
                  <li><a href="www.businesspartnersforum.com/business-services-business-setup">Business Setup</a></li>
                  <li><a href="www.businesspartnersforum.com/business-services-jv-partnerships">JV Partners</a></li>
                  <li><a href="www.businesspartnersforum.com/business-services-legal-attorneys">Legal Attorneys</a></li>
                </ul>
              </li>
              <li><a href="#">Professional Services</a>
                <ul>
                  <li><a href="www.businesspartnersforum.com/professional-services-social-media-ads">Social Media Ads</a></li>
                  <li><a href="www.businesspartnersforum.com/professional-services-web-media">Web Media</a></li>
                  <li><a href="www.businesspartnersforum.com/professional-services-recruitment">Recruitment</a></li>
                  <li><a href="www.businesspartnersforum.com/professional-services-outsourcing">Outsourcing</a></li>
                  <li><a href="www.businesspartnersforum.com/professional-services-general-contracting">General Contracting</a></li>
                </ul>
              </li>
              <li><a href="www.businesspartnersforum.com/other-services">Other Services</a></li>
              <li><a href="www.businesspartnersforum.com/free-advertisement">Free Ads</a>
              <!--
                <ul>
                  <li><a href="#">Applicant</a></li>
                  <li><a href="#">Freelancer</a></li>
                  <li><a href="#">Service Providers</a></li>
                  <li><a href="#">Business Providers</a></li>
                </ul>
              -->
              </li>
              <li><a style="color:#757575" href="#">Login</a>
              <!--
                <ul>
                  <li><a href="#">Applicant</a></li>
                  <li><a href="#">Freelancer</a></li>
                  <li><a href="#">Service Providers</a></li>
                  <li><a href="#">Business Providers</a></li>
                </ul>
              -->
              </li>
              <li><a href="www.businesspartnersforum.com/contact-us">Contact Us</a></li>
            </ul>
        </li>
    </ul>
  </div>
  <a href="/"><img src="<?php echo get_template_directory_uri();?>/assets/logos/bpf_small.png" height="90px" style="margin-top: -12.5px"/></a>
  <div flex="5" flex-gt-md="20" hide-sm hide-xs></div>
  <div id="primary_nav_wrap" layout-padding hide-sm hide-xs>
    <ul>
      <li><a href="#">About Us</a>
        <ul class="md-whiteframe-1dp">
          <li><a href="www.businesspartnersforum.com/about-us-business-strategy">Business Strategy</a></li>
          <li><a href="www.businesspartnersforum.com/about-us-owners-message">Owner's Message</a></li>
          <li><a href="www.businesspartnersforum.com/about-us-partners-message">Partner's Message</a></li>
          <!--<li><a href="#">Our Partners</a>-->
        </ul>
      </li>
      <li><a href="#">Business Services</a>
        <ul class="md-whiteframe-1dp">
          <li><a href="www.businesspartnersforum.com/business-services-local-sponsorship">Local Sponsorship</a></li>
          <li><a href="www.businesspartnersforum.com/business-services-business-setup">Business Setup</a></li>
          <li><a href="www.businesspartnersforum.com/business-services-jv-partnerships">JV Partners</a></li>
          <li><a href="www.businesspartnersforum.com/business-services-legal-attorneys">Legal Attorneys</a></li>
        </ul>
      </li>
      <li><a href="#">Professional Services</a>
        <ul class="md-whiteframe-1dp">
          <li><a href="www.businesspartnersforum.com/professional-services-social-media-ads">Social Media Ads</a></li>
          <li><a href="www.businesspartnersforum.com/professional-services-web-media">Web Media</a></li>
          <li><a href="www.businesspartnersforum.com/professional-services-recruitment">Recruitment</a></li>
          <li><a href="www.businesspartnersforum.com/professional-services-outsourcing">Outsourcing</a></li>
          <li><a href="www.businesspartnersforum.com/professional-services-general-contracting">General Contracting</a></li>
        </ul>
      </li>
      <li><a href="www.businesspartnersforum.com/other-services">Other Services</a></li>
      <li><a href="www.businesspartnersforum.com/free-advertisement">Free Ads</a>
      <!--
        <ul>
          <li><a href="#">Applicant</a></li>
          <li><a href="#">Freelancer</a></li>
          <li><a href="#">Service Providers</a></li>
          <li><a href="#">Business Providers</a></li>
        </ul>
      -->
      </li>
      <li><a style="color:#757575" href="#">Login</a>
      <!--
        <ul>
          <li><a href="#">Applicant</a></li>
          <li><a href="#">Freelancer</a></li>
          <li><a href="#">Service Providers</a></li>
          <li><a href="#">Business Providers</a></li>
        </ul>
      -->
      </li>
      <li><a href="www.businesspartnersforum.com/contact-us">Contact Us</a></li>
    </ul>
   </div>
</div>

<script>
$(window).scroll(function(){
    if ($(window).scrollTop() >= 100) {
       $('nav').addClass('fixed-header');
    }
    else {
       $('nav').removeClass('fixed-header');
    }
});
</script>

<!--
<md-toolbar id="navbar" class="md-menu-toolbar md-whiteframe-1dp">
    <div layout="row">
        <md-toolbar-filler style="background-color:#FFFFFF;" flex="20" layout layout-align="center center">
            <img flex-offset="5" src="<?php //echo get_template_directory_uri();?>/assets/logos/logo.png" style="">
        </md-toolbar-filler>
        <div flex layout-align="center center" style="background-color: #FFFFFF">
            <md-menu-bar layout="row" layout-fill>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Home</h3>
                    </button>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>About Us</h3>
                    </button>
                    <md-menu-content>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/about-us-business-strategy">
                                Business Strategy
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/about-us-owners-message">
                                Owner's Message
                            </md-button>
                        </md-menu-item>
                    </md-menu-content> 
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Business Services</h3>
                    </button>
                    <md-menu-content>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-local-sponsorship">
                                Local Sponsorship
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-business-setup">
                                Business Setup
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-jv-partnership">
                                JV Partnership
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-legal-attorneys">
                                Legal Attorneys
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-pr-services">
                                PR Services
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/business-services-criminal-civil-case">
                                Criminal/Civil Case
                            </md-button>
                        </md-menu-item>
                    </md-menu-content>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Professional Services</h3>
                    </button>
                    <md-menu-content>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-social-media-ads">
                                Social Media Ads
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-web-media">
                                Web Media
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-recruitment">
                                Recruitment/Manpower
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-outsourcing">
                                Outsourcing/Headhunting
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-general-contracting">
                                General Contracting
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/professional-services-erp-solutions">
                                ERP Solutions
                            </md-button>
                        </md-menu-item>
                    </md-menu-content>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Service Providers</h3>
                    </button>
                    <md-menu-content>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/service-providers">
                                Registration/Login
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/service-providers-our-partners">
                                Our Partners
                            </md-button>
                        </md-menu-item>
                    </md-menu-content>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Blogs</h3>
                    </button>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Careers</h3>
                    </button>   
                    <md-menu-content>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/careers-business-officers">
                                Online Business Officers
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/careers-applicants">
                                Applicants
                            </md-button>
                        </md-menu-item>
                        <md-menu-item>
                            <md-button href="www.businesspartnersforum.com/careers-freelancers">
                                Freelancers
                            </md-button>
                        </md-menu-item>
                    </md-menu-content>
                </md-menu>
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Gallery</h3>
                    </button>
                </md-menu> 
                <md-menu>
                    <button ng-click="$mdMenu.open()">
                        <h3>Contact Us</h3>
                    </button>
                </md-menu>  
            </md-menu-bar>
        </div>
        <md-toolbar-filler style="background-color:#FFFFFF;" flex="20" layout layout-align="center center">
            <img src="<?php echo get_template_directory_uri();?>/assets/logos/overseas.jpg" style="">
        </md-toolbar-filler>
</div>
</md-toolbar>
-->