	<!--/* Template Name: Free_Ads */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/free_ads.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Free Advertisement</h2>
		    	<div ng-cloak flex layout="row" id="bulletin" layout-xs="column" layout-sm="column" style="background-color:#FFFFFF">
				    <div hide-xs hide-sm flex="5"></div>
				    <p flex="45" flex-xs="100" flex-sm="100" align="justify" class="md-body-1">
				    	Moving a step ahead and bringing one of the most <b>Unique Business Features</b> Globally, Business Partners Forum is introducing absolutely a Free……. Yes a Free Advertisement platform where anyone from an Individual who is doing some Small business to Large scale companies world-wide can register, upload their <b>Products images, Company portfolio, Services</b> Live by using our <b>Free Advertisement Platform. Sounds Appealing…………..</b>
				    	<br/><br/>
						The Advertisement Platform will be live by <b>10th of November, 2017</b> and <b>Registration</b> will be starting <b>Live</b> and <b>Online</b> from <b>5th of November, 2017.</b>
						<br/><br/>
						<b>So what is making you to wait?</b> Just click the <b>Booking NOW Option</b>, fill your contact, business details and a request to book you to be live on our Advertisement Page.
			    	</p>
			    	<div flex="5"></div>
				    <div ng-cloak ng-controller="Bulletins" flex="40" flex-xs="100" flex-sm="100" layout-padding class="md-whiteframe-1dp left">
				        <h2 style="color:#FFFFFF">Our Latest</h2>
				        <md-divider style="border-color:#FFFFFF"></md-divider>
				        <div flex class="free_ads_bulletin" style="height: 200px; overflow: hidden">
				            <md-list>
				                <div ng-repeat="item in ads">
				                   <div layout="row">
				                       <p class="md-body-1" flex style="color:#FFFFFF;font-size:75%">
				                       {{item.content}}
				                       </p>
				                   </div>
				                   <md-divider style="border-color:#FFFFFF"></md-divider>
				               </div>
				           </md-list>
				       </div>
				   </div>
				</div>
	    	</div>

	    	<!-- OUR OFFICIAL PARTNERS -->
			<div ng-cloak flex ng-controller="Tinycarousel" style="background-color:#FFFFFF">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">Our Products</h2>
			  </center>
			  <br/>
			  <center>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div flex="5"></div>
				    <div flex="90" class="ads-carousel">
				      <div ng-repeat="item in ads">
				        <img src="{{item.src}}" height="200" width="200"/>
				      </div>
				    </div>
				    <div flex="5"></div>
			    </div>
			  </center>
			  <center>
			  <h3 style="color:#72012C">Advertise your Products as above</h3>
			  </center>
			  <script type="text/javascript">
			    $(document).ready(function(){
			      $('.ads-carousel').slick({
			        dots: true,
			        infinite: true,
			        speed: 700,
			        autoplay:true,
			        autoplaySpeed: 2000,
			        arrows:true,
			        slidesToShow: 4,
			        slidesToScroll: 1,
			        responsive: [
			        {
			          breakpoint: 1024,
			          settings: {
			            slidesToShow: 3,
			            slidesToScroll: 3,
			            infinite: true,
			            dots: true
			          }
			        },
			        {
			          breakpoint: 600,
			          settings: {
			            slidesToShow: 2,
			            slidesToScroll: 2,
			            dots: false
			          }
			        },
			        {
			          breakpoint: 480,
			          settings: {
			            slidesToShow: 1,
			            slidesToScroll: 1,
			            dots: false
			          }
			        }
			        ]
			      });
			    });
			  </script>
			</div>

	    	<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Hurry Up and Book Now/Live Chat....</h4>
	    	<h4 hide-gt-md style="color:#72012C">Hurry Up and Book Now/Live Chat....</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Book Now</md-button>
				</div>
			</div>
			</div>

	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>