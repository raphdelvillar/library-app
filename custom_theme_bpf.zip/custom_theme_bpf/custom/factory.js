//FACTORY
//LOGIN
bpf.factory('Login', function($http, $rootScope){
	return {
		login : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/login',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data) 
			});
		}
	}
})

//BULLETIN
bpf.factory('Bulletins', function($http, $rootScope) {
	return {
		getBulletin : function(data) {
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bulletin/getBulletin',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: data
			})
		},
		add : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bulletin/add',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		},
		update : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bulletin/update',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		},
		uploadphoto : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bulletin/uploadphoto',
				headers: { 'Content-Type' : undefined },
				data: data
			})
		},
		delete : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bulletin/delete',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		}
	}
})

//ADMIN
bpf.factory('Admins', function($http, $rootScope) {
	return {
		contract : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/contract',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},
		uploadsignatures : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/uploadsignatures',
				headers: { 'Content-Type' : undefined },
				data: data
			})
		},
		get : function(){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/get',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }
			});
		},
		add : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/add',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},
		changepw : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/changepw',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},
		delete : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/admins/delete',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		}
	}
})

//REGISTER
bpf.factory('Register', function($http, $rootScope) {
	return {
		checkmail : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/register/checkmail',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},
		registerapp : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/register',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},

		uploadcv : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/uploadcv',
				headers: { 'Content-Type' : undefined },
				data: data
			})
		},

		uploadphoto : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/uploadphoto',
				headers: { 'Content-Type' : undefined },
				data: data
			})
		},

		registerbp : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bp/register',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},

		bpuploadbrochure : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bp/uploadbrochure',
				headers: { 'Content-Type' : undefined },
				data: data
			});
		},

		registersp : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/sp/register',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			});
		},

		spuploadbrochure : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/sp/uploadbrochure',
				headers: { 'Content-Type' : undefined },
				data: data
			});
		},

		spuploadphoto : function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/sp/uploadphoto',
				headers: { 'Content-Type' : undefined },
				data: data
			});
		},
	}
})

//APPLICANTS
bpf.factory('Applicants', function($http, $rootScope){
	return {
		getapp : function(){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/getapp',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
			})
		},
		getfre : function(){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/getfre',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
			})
		},
		appcontact: function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/applicants/appcontact',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		}
	}
})

//SERVICEPROVIDER
bpf.factory('ServiceProvider', function($http, $rootScope){
	return {
		get : function(){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/sp/get',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
			})
		},
		contact: function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/sp/contact',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		}
	}
})

//BUSINESS PROVIDER
bpf.factory('BusinessProvider', function($http, $rootScope){
	return {
		get : function(){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bp/get',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
			})
		},
		contact: function(data){
			return $http({
				method: 'POST',
				url: $rootScope.url + '/' + 'laravel/public/api/bp/contact',
				headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
				data: $.param(data)
			})
		}
	}
})
