bpf.controller('Bulletins', function($anchorScroll, $scope, $rootScope, $timeout, $location, $log, $mdDialog, Bulletins){
	$scope.marquee = function(){
		Bulletins.getBulletin('home')
		.success(function(response){
			$scope.bulletins = response;
			$timeout(function(){
				$('#home_bulletin').marquee({
	                duration: 10000,
	                direction: 'up',
	                pauseOnHover: true,
	                startVisible: true,
	            });
            	$scope.active = true;
			}, 1000)
		});

		Bulletins.getBulletin('latest')
		.success(function(response){
			$scope.news = response;
			$timeout(function(){
				$('#home_news').marquee({
					duration: 10000,
					direction: 'up',
					pauseOnHover: true,
					startVisible: true,
				});
				$scope.active = true;
			}, 1000)
		});

		Bulletins.getBulletin('ads')
		.success(function(response){
			$scope.ads = response;
			$timeout(function(){
				$('#free_ads_bulletin').marquee({
					duration: 10000,
					direction: 'up',
					pauseOnHover: true,
					startVisible: true,
				});
				$scope.active = true;
			}, 1000)
		})
	}

	$scope.init = function(){
		$scope.search = '';

		Bulletins.getBulletin('home')
		.success(function(response){
			$scope.bulletin = response;
		})

		Bulletins.getBulletin('latest')
		.success(function(response){
			$scope.news = response;
		})

		Bulletins.getBulletin('ads')
		.success(function(response){
			$scope.ads = response;
		})
	}
	
	$scope.showAlert = function(ev, subject, title, content) {
		$mdDialog.show(
	      $mdDialog.alert()
	        .parent(angular.element(document.body))
	        .clickOutsideToClose(true)
	        .title(subject + ' : ' + title)
	        .textContent(content)
	        .ariaLabel('Alert Dialog Demo')
	        .ok('Done')
	        .targetEvent(ev)
	    ).then(function(){
	    	$location.hash("business-philosophy");
	    	$anchorScroll();
	    })
    };

	$scope.delete = function(id){
		$anchorScroll.yOffset=0;
		$anchorScroll();
		var confirm = $mdDialog.confirm()
		.title('Confirm Deletion')
		.textContent('Wold you like delete this bulletin?')
		.cancel('Yes')
		.ok('No')

		$mdDialog.show(confirm).then(function() {
			$scope.delete = {
				'id' : id
			};

			Bulletins.delete($scope.delete)
			.success(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
			      $mdDialog.alert()
			        .clickOutsideToClose(true)
			        .title('Result')
			        .textContent('Bulletin Item has been successfully deleted!.')
			        .ok('Ok')
			    );
			    $scope.init();
			})
		}, function() {
			//do nothing
		});
	}

	$scope.update = function(item){
		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show({
		  locals:{data: item},
		  scope: $scope,
	      controller: UpdateDialogController,
	      templateUrl: $rootScope.url + '/' + 'wp-content/themes/custom_theme_bpf/service_providers/dialog/edit.bulletin.tmpl.html',
	      clickOutsideToClose:false,
	      fullscreen: true // Only for -xs, -sm breakpoints.
	    })
	}

	$scope.add = function(){
		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show({
		  scope: $scope,
	      controller: AddDialogController,
	      templateUrl: $rootScope.url + '/' + 'wp-content/themes/custom_theme_bpf/service_providers/dialog/add.bulletin.tmpl.html',
	      clickOutsideToClose:false,
	      fullscreen: true // Only for -xs, -sm breakpoints.
	    })
	}

	function UpdateDialogController($scope, $rootScope, $anchorScroll, $mdDialog, data, Bulletins){
		$scope.editBulletin = data;
		$scope.edit = function(){
			if($scope.photo == undefined){
				$scope.editBulletin.src = '';
				Bulletins.update($scope.editBulletin)
				.success(function(response){
					$scope.init();
					$anchorScroll.yOffset=0;
					$anchorScroll();
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Result')
						.textContent('Bulletin Item has been successfully updated!')
						.ok('Ok')
					);
				})
				.error(function(response){
					$anchorScroll.yOffset=0;
					$anchorScroll();
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
						.ok('Ok')
					);
				})
				
			}else{
				if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
					var formData = new FormData();
					angular.forEach($scope.photo, function(value, key){
					formData.append('file', value);
					});

					Bulletins.uploadphoto(formData)
					.success(function(response){
						$scope.editBulletin.src = response;
						
						Bulletins.updateBulletin($scope.editBulletin)
						.success(function(response){
							$scope.init();
							$anchorScroll.yOffset=0;
							$anchorScroll();
							$mdDialog.show(
						      $mdDialog.alert()
						        .clickOutsideToClose(true)
						        .title('Result')
						        .textContent('Bulletin Item has been successfully updated!')
						        .ok('Ok')
						    );
						})
						.error(function(response){
							$anchorScroll.yOffset=0;
							$anchorScroll();
							$mdDialog.show(
						      $mdDialog.alert()
						        .clickOutsideToClose(true)
						        .title('Error')
						        .textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
						        .ok('Ok')
						    );
						})

					})
					.error(function(response){
						$anchorScroll.yOffset=0;
						$anchorScroll();	
						$mdDialog.show(
						    $mdDialog.alert()
						    .clickOutsideToClose(true)
						    .title('Error')
						    .textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
						    .ok('Ok')
						);
					})
				}else{
					$anchorScroll.yOffset=0;
					$anchorScroll();
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('You can only upload photo in .png, .jpeg and .jpg format. Please try again. Thanks')
						.ok('Ok')
					);
				}
			}
		}

		$scope.cancel = function(){
			$mdDialog.cancel();
		}
	}

	function AddDialogController($scope, $rootScope, $anchorScroll, $mdDialog, Bulletins){
		$scope.addBulletin = {
			id: '',
			title: '',
			content: '',
			src: '',
			starred: ''
		};
		$scope.cancel = function(){
			$mdDialog.cancel();
		}

		$scope.add = function(){
			if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
				var formData = new FormData();
				angular.forEach($scope.photo, function(value, key){
				formData.append('file', value);
				});

				Bulletins.uploadphoto(formData)
				.success(function(response){
					$scope.addBulletin.src = response;
						
					Bulletins.add($scope.addBulletin)
					.success(function(response){
						$scope.init();
						$anchorScroll.yOffset=0;
						$anchorScroll();
						$mdDialog.show(
							$mdDialog.alert()
						    .clickOutsideToClose(true)
						    .title('Result')
						    .textContent('Bulletin Item has been successfully updated!')
						    .ok('Ok')
						);
					})
					.error(function(response){
						$anchorScroll.yOffset=0;
						$anchorScroll();
						$mdDialog.show(
						    $mdDialog.alert()
						    .clickOutsideToClose(true)
						    .title('Error')
						    .textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
						    .ok('Ok')
						);
					})

				})
				.error(function(response){
					$anchorScroll.yOffset=0;
					$anchorScroll();
					$mdDialog.show(
					    $mdDialog.alert()
					    .clickOutsideToClose(true)
					    .title('Error')
					    .textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
					    .ok('Ok')
					);
				})
			}else{
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('You can only upload photo in .png, .jpeg and .jpg format. Please try again. Thanks')
					.ok('Ok')
				);
			}
		}


	}

	$scope.init();
	$scope.marquee();
});