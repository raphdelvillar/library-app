bpf.controller('Masterslider', function($scope, $log){
	$scope.slides = [
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/local-sponsorship.jpg',
                caption: 'Local Sponsorship',
                description: 'Full spectrum of company establishment in Qatar from Local Sponsors, Lawyers and acquiring License.',
                link: 'www.businesspartnersforum.com/business-services-local-sponsorship',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/business-setup.jpg',
                caption: 'Business Setup',
                description: 'Strengthening your Business either as a starter/add-on in an existing business with your pre/post launching.',
                link: 'www.businesspartnersforum.com/business-serices-business-setup',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/jv-partnership.jpg',
                caption: 'JV Partnership',
                description: 'Project/Business execution in Qatar as our Joint Venture Partner either as Exclusive or on Project Basis.',
                link: 'www.businesspartnersforum.com/business-services-jv-partnership',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/legal-attorneys.jpg',
                caption: 'Legal Attorneys',
                description: 'Corporate/Indvidual Attorneys from Company Establishment to solving Criminal/Civil/Employee cases.',
                link: 'www.businesspartnersforum.com/business-services-legal-attorneys',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/social-media.jpg', 
                caption: 'Social Media Ads',
                description: 'Let us connect you to your client and be on top of the business through our Social Media advanced Solutions.',
                link: 'www.businesspartnersforum.com/professional-services-social-media-ads',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/web-media.jpg',
                caption: 'Web Media',
                description: 'Explore your clients with highly responsive websites/Web Portals/Brochures/Flyers/Graphic Designing.',
                link: 'www.businesspartnersforum.com/professional-services-web-media',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/recruitment.jpg',
                caption: 'Recruitment/Manpower',
                description: 'Worldwide Recruitment/Manpower (Blue/White Collar) for any Industry using our 20 years of Experience.',
                link: 'www.businesspartnersforum.com/professional-services-recruitment',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/outsourcing.jpg',
                caption: 'Outsourcing/Headhunting',
                description: 'Worldwide/Local outsourcing from Executive/Technical/Operational to back office staff/sales/security.',
                link: 'www.businesspartnersforum.com/professional-services-outsourcing',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/construction-management.jpg',
                caption: 'General Contracting',
                description: 'From (Project/Cost Planning), (B.I.M), (Civil/MEP), (Finishing) till hand over to Client as (Design & Build).',
                link: 'www.businesspartnersforum.com/professional-services-general-contracting',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/erp-solutions.jpg',
                caption: 'ERP Solutions',
                description: 'Turnkey Software/Network/ERP Solution Providers (Web/Cloud based) with Oracle as our Gold Partner.',
                link: 'www.businesspartnersforum.com/professional-services-erp-solutions',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/domain-hosting.jpg',
                caption: 'Domain Hosting',
                description: 'Secured and Protected Emails from Domain Registration/Configuration to Web Hosting and Email setups.',
                link: 'www.businesspartnersforum.com/professional-services-domain-hosting',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/hr-solutions.jpg',
                caption: 'HR Solutions',
                description: 'From Complete Infrastructure/Company Restructing/to setting up Corporate MIS based HR Solutions.',
                link: 'www.businesspartnersforum.com/professional-services-hr-solutions',
            },
            {
                src: 'wp-content/themes/custom_theme_bpf/assets/master-slider/project-consultancy.jpg',
                caption: 'Project Consultancy',
                description: 'Project Solutions from Pre/Post Execution through our Project Consultants, Cost Planners and Site Team.',
                link: 'www.businesspartnersforum.com/professional-services-project-consultancy',
            }
    ];

    $scope.options = {
            clicking: true,
            sourceProp: 'src',
            visible: 5,
            perspective: 35,
            startSlide: 0,
            border: 0,
            dir: 'ltr',
            width: 500,
            height: 300,
            space: 220,
            autoRotationSpeed: 6000,
            loop: true
    };

    $scope.lastSlide = function(index) {
        $log.log('Last Slide Selected callback triggered. \n == Slide index is: ' + index + ' ==');
    }

    $scope.beforeChange = function(index) {
        $log.log('Before Slide Change callback triggered. \n == Slide index is: ' + index + ' ==');
    }

    $scope.selectedClick = function(index) {
        $log.log('Selected Slide Clicked callback triggered. \n == Slide index is: ' + index + ' ==');
    }

    $scope.slideChanged = function(index) {
        $log.log('Slide Changed callback triggered. \n == Slide index is: ' + index + ' ==');
    }

});