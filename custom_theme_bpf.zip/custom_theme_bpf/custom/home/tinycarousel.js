bpf.controller('Tinycarousel', function($scope, $log){
	/*
	$scope.top = [
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/all.jpg',
			'caption': 'Our Activities'
		},
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/web design.jpg',
			'caption': 'Web Media'
		},
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/local sponsorship and business set-up.jpg',
			'caption': 'Local Sponsorship and Business Set-up'
		},
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/manpowers services available.jpg',
			'caption': 'Manpower Services Available'
		},
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/proffesional lawyers.jpg',
			'caption': 'Proffesional Lawyers'
		},
		{
			'src': 'wp-content/themes/custom_theme_bpf/assets/advertisement/social media online business officers.jpg',
			'caption': 'Social Media Online Business Officers'
		},
	];
	*/

	$scope.top = [
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/outlook.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/overseas.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/outlook-tc.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/seasons-kitchen.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/outlook-as.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/outlook-tr.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/lucy_vela_beauty_salon.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/silver_nitrate_trading_contracting.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/outlook_garage.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/sasco_facility_management.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/alashbal_primary_school.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/alashbal_international_kindergarten.jpeg'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-partners/young_achievers_montessori.jpeg'
	 }
	];

	$scope.bottom = [
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/aeb.jpg',
	 	'link': 'http://www.aeb-qatar.com'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/wenqatar.png',
	 	'link': 'http://www.wenqatar.com'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/latifia2.jpg',
	 	'link': 'http://www.latifia.com'
	 },
	 { 
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/1.jpg',
		'caption': 'SensorTec',
		'link': '#'
	 },
	 { 
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/2.jpg',
		'caption': 'Middle East Foundations Group LLC',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/4.jpg',
		'caption': 'Hagen Group',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/5.jpg',
		'caption': 'Turner & Townsend',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/6.jpg',
		'caption': 'Parchettificio Toscano',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/7.jpg',
		'caption': 'ENVISION Global Inc.',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/8.jpg',
		'caption': 'Econpile',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/9.jpg',
		'caption': 'Catic - Qatar',
		'link': '#'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/our-affiliates/10.jpg',
		'caption': 'Tilke',
		'link': '#'
	 }
	];

	$scope.ads = [
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/business-setup.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/construction-management.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/domain-hosting.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/jv-partnership.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/legal-attorneys.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/local-sponsorship.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/outsourcing.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/recruitment.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/social-media.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/web-media.jpg',
	  },
	  {
	  	'src': '../wp-content/themes/custom_theme_bpf/assets/master-slider/digital_media.jpeg',
	  }
	];
})