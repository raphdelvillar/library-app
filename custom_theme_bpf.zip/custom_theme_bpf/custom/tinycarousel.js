bpf.controller('tinycarouselController', function($scope, $log){
	$scope.top = [
	 { 
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20245467_1899385080310613_3623568213353250812_n.jpg',
		'caption': 'SensorTec'
	 },
	 { 
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20293082_1899385053643949_6860001621824176817_n.jpg',
		'caption': 'Middle East Foundations Group LLC'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20374230_1899385136977274_8497896483168899268_n.jpg',
		'caption': 'Hagen Group'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20374253_1899384983643956_4773974955544741493_n.jpg',
		'caption': 'Turner & Townsend'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20374402_1899385063643948_8707098788184306931_n.jpg',
		'caption': 'Parchettificio Toscano'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20375634_1899385013643953_8025414718192133507_n.jpg',
		'caption': 'ENVISION Global Inc.'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20430106_1899384993643955_6498388724814987425_n.jpg',
		'caption': 'Econpile'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20476137_1899385126977275_3193518496954018250_n.jpg',
		'caption': 'Catic - Qatar'
	 },
	 {
		'src': 'wp-content/themes/custom_theme_bpf/assets/companies-on-board/20479434_1899385096977278_4425407421712664712_n.jpg',
		'caption': 'Tilke'
	 }
	];

	$scope.bottom = [
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv1.jpg',
	 	'caption': 'With the chairman of Savills- Project Company in Singapore.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv2.jpg',
	 	'caption': 'With the CEOs of PTE Tuscano (Italy) Hagen-(Portugal) Catic- (China)in a business conference.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv3.jpg',
	 	'caption': 'With the CEO of Strong Force- Australia in a Business meeting.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv4.jpg',
	 	'caption': 'With my Business Team member in a contract ceremony with Strong Force Australia.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv5.jpg',
	 	'caption': 'In Philipines, while attending a Top Business ceremony.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv6.jpg',
	 	'caption': 'CEO of Catic- China signing company establishment papers in Qatar.'	 	
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv7.jpg',
	 	'caption': 'CEO of Catic (Chinese Company) in a Business conference arranged by PFS.'	 	
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv8.jpg',
	 	'caption': 'Signing Company Establishment contract with the Chairman and CEO of PTE- Tuscano Italy.'	 	
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv9.jpg',
	 	'caption': 'CEO & Chairman of PTE- Tuscano Italy in Company launching ceremony.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv10.jpg',
	 	'caption': 'With Group partners in 2011.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv11.jpg',
	 	'caption': 'With Directors of Mcnally Design International in 2011.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv12.jpg',
	 	'caption': 'With CEO of Sensortec- Canada'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv13.jpg',
	 	'caption': 'With CEOs and senior Management members during Project Qatar Exhibition in 2011'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv14.jpg',
	 	'caption': 'With CEO of Patton International Ireland.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv15.jpg',
	 	'caption': 'With CEO of Patton International Ireland.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv16.jpg',
	 	'caption': 'With CEO and MD of Trust Hospitality USA.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv17.jpg',
	 	'caption': 'Signing occassion in 2011 with Mr. Steve- MD of Strong Force Australia to have establishment in Qatar.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv18.jpg',
	 	'caption': 'Signing ceremony in 2010 with Mr. Sherif, Owner and MD of IDDI USA for company establishment in Qatar.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv19.jpg',
	 	'caption': 'Signing business contract with Mr. Jason Morris, owner of Jason Morris for company establishment in Qatar.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv20.jpg',
	 	'caption': 'With Mr. Greham in 2010 during establishment of Bond Bryan (UK based Consultants) in Qatar'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv21.jpg',
	 	'caption': 'Signing business contract with Chairman of JP Contracting in Warsaw Poland.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv22.jpg',
	 	'caption': 'In Singapore with Top officials'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv23.jpg',
	 	'caption': 'Meeting in 2011 with owner and MD of Melham- USA for Interior designing business in Qatar.'
	 },
	 {
	 	'src': 'wp-content/themes/custom_theme_bpf/assets/business-ventures/bv24.jpg',
	 	'caption': 'PTE- Tuscano - Italy for company Establishment in Qatar in 2010 with IDDI members as guest.'
	 },
	];
})