bpf.controller('Registration', function($scope, $rootScope, $anchorScroll, $location, $mdDialog, Register){
	$link = $location.absUrl().split('?')[1];
	$scope.registration = $link;

	$scope.init = function(){
		$rootScope.loading = 'no';
		$scope.applicants = {
			username: '',
			password: '',
			name: '',
			title: '',
			position: '',
			others: '',
			bio: '',
			nationality: '',
			mobile: '',
			email: '',
			cv: '',
			photo: '',
			referral: '',
			type: ''
		};

		$scope.freelancers = {
			username: '',
			password: '',
			name: '',
			title: '',
			position: '',
			others: '',
			ba: '',
			bio: '',
			nationality: '',
			mobile: '',
			email: '',
			cv: '',
			photo: '',
			referral: '',
			type: ''
		};

		$scope.business_officers = {
			username: '',
			password: '',
			name: '',
			title: '',
			position: '',
			others: '',
			ba: '',
			bio: '',
			nationality: '',
			mobile: '',
			email: '',
			cv: '',
			photo: '',
			referral: '',
			type: ''
		};

		$scope.service_providers = {
			username: '',
			password: '',
			name: '',
			country: '',
			sector: '',
			others: '',
			landline: '',
			mobile: '',
			website: '',
			contact: '',
			brochure: '',
			photo: '',
			referral: '',
			type: ''
		};

		$scope.loading = 'no';
		$scope.countries = $rootScope.countries;
	}
	$scope.init();

	$scope.register_applicant = function(){
		$scope.loading = 'yes';
		$scope.applicants.type = 'Applicant';
		Register.checkmail($scope.applicants)
		.success(function(response){
			if(response == 'success'){
				if($scope.cv[0].type == 'application/pdf' || $scope.cv[0].type == 'application/msword' || $scope.cv[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
					var formData = new FormData();
					angular.forEach($scope.cv, function(value, key){
						formData.append('file', value);
					});

					Register.uploadcv(formData)
					.success(function(response){
						$scope.applicants.cv = response;
						if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
							var formData = new FormData();
							angular.forEach($scope.photo, function(value, key){
								formData.append('file', value);
							});

							Register.uploadphoto(formData)
							.success(function(response){
								$scope.applicants.photo = response;
								Register.registerapp($scope.applicants)
								.success(function(response){
									$scope.init();
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Result')
										.textContent('Thank you for sending your resume/cv!')
										.ok('Ok')
									).then(function(){
										$location.path($rootScope.url + '/careers-applicants/');
									});
								})
								.error(function(response){
									$scope.loading = 'no';
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Error')
										.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
										.ok('Ok')
										);
								})
							})
							.error(function(response){
								$scope.loading = 'no';
								$mdDialog.show(
									$mdDialog.alert()
									.clickOutsideToClose(true)
									.title('Error')
									.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
									.ok('Ok')
									);
							})
						}else{
							$scope.loading = 'no';
							$mdDialog.show(
								$mdDialog.alert()
								.clickOutsideToClose(true)
								.title('Error')
								.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
								.ok('Ok')
								);
						}
					})
					.error(function(response){
						$scope.loading = 'no';
						$mdDialog.show(
							$mdDialog.alert()
							.clickOutsideToClose(true)
							.title('Error')
							.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
							.ok('Ok')
							);
					});
				}else{
					$scope.loading = 'no';
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
						.ok('Ok')
						);
				}
			}else{
				$scope.loading = 'no';
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Username already taken. Kindly choose another email address!')
					.ok('Ok')
					);
			}
		})
		.error(function(response){
			$scope.loading = 'no';
			$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Error')
				.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
				.ok('Ok')
				);
		});
	}

	$scope.register_freelancers = function(){
		$scope.loading = 'yes';
		$scope.freelancers.type = 'Freelancer';
		Register.checkmail($scope.freelancers)
		.success(function(response){
			if(response == 'success'){
				if($scope.cv[0].type == 'application/pdf' || $scope.cv[0].type == 'application/msword' || $scope.cv[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
					var formData = new FormData();
					angular.forEach($scope.cv, function(value, key){
						formData.append('file', value);
					});

					Register.uploadcv(formData)
					.success(function(response){
						$scope.freelancers.cv = response;
						if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
							var formData = new FormData();
							angular.forEach($scope.photo, function(value, key){
								formData.append('file', value);
							});

							Register.uploadphoto(formData)
							.success(function(response){
								$scope.freelancers.photo = response;
								Register.registerapp($scope.freelancers)
								.success(function(response){
									$scope.init();
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Result')
										.textContent('Thank you for sending your resume/cv!')
										.ok('Ok')
									).then(function(){
										$location.path($rootScope.url + '/careers-freelancers/');
									});
								})
								.error(function(response){
									$scope.loading = 'no';
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Error')
										.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
										.ok('Ok')
										);
								})
							})
							.error(function(response){
								$scope.loading = 'no';
								$mdDialog.show(
									$mdDialog.alert()
									.clickOutsideToClose(true)
									.title('Error')
									.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
									.ok('Ok')
									);
							})
						}else{
							$scope.loading = 'no';
							$mdDialog.show(
								$mdDialog.alert()
								.clickOutsideToClose(true)
								.title('Error')
								.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
								.ok('Ok')
								);
						}
					})
					.error(function(response){
						$scope.loading = 'no';
						$mdDialog.show(
							$mdDialog.alert()
							.clickOutsideToClose(true)
							.title('Error')
							.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
							.ok('Ok')
							);
					});
				}else{
					$scope.loading = 'no';
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
						.ok('Ok')
						);
				}
			}else{
				$scope.loading = 'no';
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Username already taken. Kindly choose another email address!')
					.ok('Ok')
					);
			}
		})
		.error(function(response){
			$scope.loading = 'no';
			$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Error')
				.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
				.ok('Ok')
				);
		});
	}

	$scope.register_business_officers = function(){
		$scope.loading = 'yes';
		$scope.business_officers.type = 'Business Officer';
		Register.checkmail($scope.business_officers)
		.success(function(response){
			if(response == 'success'){
				if($scope.cv[0].type == 'application/pdf' || $scope.cv[0].type == 'application/msword' || $scope.cv[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
					var formData = new FormData();
					angular.forEach($scope.cv, function(value, key){
						formData.append('file', value);
					});

					Register.uploadcv(formData)
					.success(function(response){
						$scope.business_officers.cv = response;
						if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
							var formData = new FormData();
							angular.forEach($scope.photo, function(value, key){
								formData.append('file', value);
							});

							Register.uploadphoto(formData)
							.success(function(response){
								$scope.business_officers.photo = response;
								Register.registerapp($scope.business_officers)
								.success(function(response){
									$scope.init();
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Result')
										.textContent('Thank you for sending your resume/cv!')
										.ok('Ok')
									).then(function(){
										$location.path($rootScope.url + '/careers-business-officers/');
									});
								})
								.error(function(response){
									$scope.loading = 'no';
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Error')
										.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
										.ok('Ok')
										);
								})
							})
							.error(function(response){
								$scope.loading = 'no';
								$mdDialog.show(
									$mdDialog.alert()
									.clickOutsideToClose(true)
									.title('Error')
									.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
									.ok('Ok')
									);
							})
						}else{
							$scope.loading = 'no';
							$mdDialog.show(
								$mdDialog.alert()
								.clickOutsideToClose(true)
								.title('Error')
								.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
								.ok('Ok')
								);
						}
					})
					.error(function(response){
						$scope.loading = 'no';
						$mdDialog.show(
							$mdDialog.alert()
							.clickOutsideToClose(true)
							.title('Error')
							.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
							.ok('Ok')
							);
					});
				}else{
					$scope.loading = 'no';
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
						.ok('Ok')
						);
				}
			}else{
				$scope.loading = 'no';
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Username already taken. Kindly choose another email address!')
					.ok('Ok')
					);
			}
		})
		.error(function(response){
			$scope.loading = 'no';
			$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Error')
				.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
				.ok('Ok')
				);
		});
	}

	$scope.register_service_providers = function(){
		$scope.loading = 'yes';
		$scope.service_providers.type = 'Service Provider';
		Register.checkmail($scope.service_providers)
		.success(function(response){
			if(response == 'success'){
				if($scope.cv[0].type == 'application/pdf' || $scope.cv[0].type == 'application/msword' || $scope.cv[0].type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'){
					var formData = new FormData();
					angular.forEach($scope.cv, function(value, key){
						formData.append('file', value);
					});

					Register.spuploadbrochure(formData)
					.success(function(response){
						$scope.service_providers.cv = response;
						if($scope.photo[0].type == 'image/png' || $scope.photo[0].type == 'image/jpeg' || $scope.photo[0].type == 'image/jpg'){
							var formData = new FormData();
							angular.forEach($scope.photo, function(value, key){
								formData.append('file', value);
							});

							Register.spuploadphoto(formData)
							.success(function(response){
								$scope.service_providers.photo = response;
								Register.registersp($scope.service_providers)
								.success(function(response){
									$scope.init();
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Result')
										.textContent('Thank you for uploading your business portfolio!')
										.ok('Ok')
									).then(function(){
										$location.path($rootScope.url + '/service-providers/');
									});
								})
								.error(function(response){
									$scope.loading = 'no';
									$mdDialog.show(
										$mdDialog.alert()
										.clickOutsideToClose(true)
										.title('Error')
										.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
										.ok('Ok')
										);
								})
							})
							.error(function(response){
								$scope.loading = 'no';
								$mdDialog.show(
									$mdDialog.alert()
									.clickOutsideToClose(true)
									.title('Error')
									.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
									.ok('Ok')
									);
							})
						}else{
							$scope.loading = 'no';
							$mdDialog.show(
								$mdDialog.alert()
								.clickOutsideToClose(true)
								.title('Error')
								.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
								.ok('Ok')
								);
						}
					})
					.error(function(response){
						$scope.loading = 'no';
						$mdDialog.show(
							$mdDialog.alert()
							.clickOutsideToClose(true)
							.title('Error')
							.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
							.ok('Ok')
							);
					});
				}else{
					$scope.loading = 'no';
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('You can only upload photo in .png, .jpeg and .jpg format!')
						.ok('Ok')
						);
				}
			}else{
				$scope.loading = 'no';
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Username already taken. Kindly choose another email address!')
					.ok('Ok')
					);
			}
		})
		.error(function(response){
			$scope.loading = 'no';
			$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Error')
				.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
				.ok('Ok')
				);
		});
	}

});