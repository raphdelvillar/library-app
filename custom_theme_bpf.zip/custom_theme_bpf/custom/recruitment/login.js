bpf.controller('Login', function($scope, $rootScope, $anchorScroll, $location, $mdDialog, Login){
	$rootScope.currState = 'Login';
	$scope.login = {
		username: '',
		password: '',
	};
	$scope.loading = 'no';

	$scope.init = function(){
		$scope.login = {
			username: '',
			password: '',
		};
		$scope.loading = 'no';
	}

	$scope.init();
	
	$scope.logmein = function(){
		console.log($scope.login);
		Login.login($scope.login)
		.success(function(response){
			if(angular.isUndefined(response.usertype)){
				$scope.init();
				alert("Error! Your user info is not found on our database. Kindly register first. Thank you!");
			}else{
				$rootScope.userID = response.userID;
				$rootScope.usertype = response.usertype;
				$rootScope.username = response.username;

				if(response.usertype == 'Business Officer' || response.usertype == 'Personal Assistant' || response.usertype == 'Admin' || response.usertype == 'Webmaster'){
					$rootScope.currState = 'Admin';
					$rootScope.contract = response.contract;
				}else if(response.usertype == 'Applicant' || response.usertype == 'Freelancer'){
					$rootScope.currState = 'Employee';
				}else if(response.usertype == 'Business Provider'){
					$rootScope.currState = 'Business Provider';
				}else if(response.usertype == 'Service Provider'){
					$rootScope.currState = 'Service Provider';
				}
			}
		})
		.error(function(response){
			$anchorScroll.yOffset=0;
			$anchorScroll();
			$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Error')
				.textContent('Error! Your user info is not found on our database. Kindly register first. Thank you!')
				.ok('Ok')
			);
		})
	}
});
