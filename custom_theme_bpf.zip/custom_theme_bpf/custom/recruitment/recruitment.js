bpf.controller('Recruitment', function($scope, $rootScope){
	$rootScope.currPage = '';
	$scope.nav = function($page){
		$rootScope.currPage = $page;
	}

});