bpf.controller('Applicants',function($scope, $rootScope, $location, $anchorScroll, $mdDialog, Applicants){
	$scope.init = function(){
		$scope.filter = 'any';
		$scope.search = {
			'$' : '',
			'name' : '',
			'title' : '',
			'position' : '',
			'nationality' : '',
			'email' : '',
		};
		Applicants.getapp()
		.success(function(response){
			$scope.applications = response;
		})
	}

	$scope.clear = function(){
		$scope.search = {
			'$' : '',
			'name' : '',
			'title' : '',
			'position' : '',
			'ba' : '',
			'nationality' : '',
			'email' : '',
		};
	}

	$scope.contact = function($name, $email){
		$scope.contact = {
			'id' : $rootScope.userID,
			'name' : $name,
			'emailto' : $email,
			'subject' : '',
			'content' : ''
		}

		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show({
		  locals:{data: $scope.contact},
		  scope: $scope,
	      controller: ContactController,
	      templateUrl: $rootScope.url + '/' + 'wp-content/themes/custom_theme_bpf/service_providers/dialog/contact.tmpl.html',
	      clickOutsideToClose:false,
	      fullscreen: true // Only for -xs, -sm breakpoints.
	    })
	};

	function ContactController($scope, $rootScope, $anchorScroll, data, Applicants){
		$scope.contact = data;
		$scope.send = function(){
			Applicants.appcontact($scope.contact)
			.success(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Result')
					.textContent('Message has been sent!')
					.ok('Ok')
				);
			})
			.error(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
					.ok('Ok')
				);
			});
		}

		$scope.cancel = function(){
			$mdDialog.cancel();
		}
	}

	$scope.init();
});