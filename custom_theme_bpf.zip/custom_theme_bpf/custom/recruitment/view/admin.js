bpf.controller('Admins', function($scope, $rootScope, $location, $anchorScroll, $mdDialog, Admins){
	$scope.init = function(){
		$scope.search = '';
		Admins.get()
		.success(function(response){
			$scope.admins = response;
		})
	}

	$scope.add = function(){
		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show({
		  scope: $scope,
	      controller: AddDialogController,
	      templateUrl: $rootScope.url + '/' + 'wp-content/themes/custom_theme_bpf/service_providers/dialog/add.admins.tmpl.html',
	      clickOutsideToClose:false,
	      fullscreen: true // Only for -xs, -sm breakpoints.
	    })
	}

	$scope.delete = function(id, username){
		var confirm = $mdDialog.confirm()
		.title('Confirm Deletion')
		.textContent('Would you like to delete this admin?')
		.ok('Yes')
		.cancel('No')

		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show(confirm).then(function(){
			$scope.delete = {
				'id' : id
			}

			Admins.delete($scope.delete)
			.success(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Result')
					.textContent('Admin ' + username + ' has been successfully deleted!')
					.ok('Ok')
				)

				$scope.init();
			})
			.error(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
					.ok('Ok')
				);
			})
		}, function(){
			//do nothing
		});
	}

	$scope.changepw = function(){
		var confirm = $mdDialog.prompt()
		.title('Change Password')
		.textContent('Please enter your new password.')
		.placeholder('New Password')
		.initialValue('')
		.ok('Confirm')
		.cancel('Cancel')

		$anchorScroll.yOffset=0;
		$anchorScroll();
		$mdDialog.show(confirm).then(function(result){
			$scope.password = {
				'id' : $rootScope.userID,
				'password' : result
			}

			Admins.changepw($scope.password)
			.success(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Result')
					.textContent('Your password has been successfully changed!')
					.ok('Ok')
				);

				$scope.init();
			})
			.error(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
					.ok('Ok')
				);
			})
		}, function(){
			//do nothing
		});


	}

	function AddDialogController($scope, $rootScope, $anchorScroll, $mdDialog, Admins){
		$scope.addAdmins = {
			username: '',
			position: '',
			signature: '',
		};

		$scope.cancel = function(){
			$mdDialog.cancel();
		}

		$scope.add = function(){
			if($scope.signature[0].type == 'image/png' || $scope.signature[0].type == 'image/jpeg' || $scope.signature[0].type == 'image/jpg'){
				var formData = new FormData();
				angular.forEach($scope.signature, function(value, key){
				formData.append('file', value);
				});

				Admins.uploadsignatures(formData)
				.success(function(response){
					$scope.addAdmins.signature = response;

					Admins.add($scope.addAdmins)
					.success(function(response){
						$scope.init();
						$anchorScroll.yOffset=0;
						$anchorScroll();
						$mdDialog.show(
							$mdDialog.alert()
						    .clickOutsideToClose(true)
						    .title('Result')
						    .textContent('Admin has been successfully updated!')
						    .ok('Ok')
						);
					})
					.error(function(response){
						$anchorScroll.yOffset=0;
						$anchorScroll();
						$mdDialog.show(
							$mdDialog.alert()
							.clickOutsideToClose(true)
							.title('Error')
							.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
							.ok('Ok')
						);
					})
				})
				.error(function(response){
					$anchorScroll.yOffset=0;
					$anchorScroll();
					$mdDialog.show(
						$mdDialog.alert()
						.clickOutsideToClose(true)
						.title('Error')
						.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
						.ok('Ok')
					);
				})
			}
		}
	}

	$scope.init();

});