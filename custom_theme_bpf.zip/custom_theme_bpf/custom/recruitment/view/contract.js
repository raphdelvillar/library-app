bpf.controller('Contract',function($scope, $rootScope, $anchorScroll, $location, $mdDialog, Admins){
	$scope.option = function($reply){

		var confirm = $mdDialog.prompt()
	      .title('Hi!')
	      .textContent('Please enter any comments about your contract below.')
	      .ariaLabel('Comments')
	      .initialValue('')
	      .ok('Send')
	      .cancel('Cancel');

	    $anchorScroll.yOffset=0;
		$anchorScroll();
	    $mdDialog.show(confirm).then(function(result){
	    	$scope.users = {
				id: $rootScope.userID,
				answer: $reply,
				message: $message
			};
			Admins.contract($scope.users)
			.success(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Result')
					.textContent('Email was sent sucessfully! Please await further instruction.')
					.ok('Ok')
				);
				$scope.contract = response.contract;

			})
			.error(function(response){
				$anchorScroll.yOffset=0;
				$anchorScroll();
				$mdDialog.show(
					$mdDialog.alert()
					.clickOutsideToClose(true)
					.title('Error')
					.textContent('Error has been encountered. Please try again later. Sorry for the inconvenience. Thank you!')
					.ok('Ok')
				);
			})

	    }, function(){
	    	$anchorScroll.yOffset=0;
			$anchorScroll();
	    	$mdDialog.show(
				$mdDialog.alert()
				.clickOutsideToClose(true)
				.title('Result')
				.textContent('Action was cancelled')
				.ok('Ok')
			);
	    });
	}
});