	<!--/* Template Name: General_Contracting */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/general_contracting.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">General Contracting</h2>
	    	<p align="justify" class="md-body-1">
		    	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam accumsan mattis lacus, sed euismod dolor. Maecenas magna nunc, molestie non vestibulum sed, vulputate id enim. Nulla turpis tortor, aliquam a nibh id, tempor posuere ligula. Nulla et lectus ac massa tincidunt laoreet. Nulla facilisi. Etiam consectetur magna at dignissim volutpat. Vivamus vitae nunc augue. Maecenas vel consectetur sapien. Nunc porta et purus et laoreet.
		    	<br/><br/>
				Cras commodo iaculis placerat. Cras justo nisl, tincidunt vitae eros a, rhoncus varius diam. Sed ullamcorper augue quis placerat facilisis. Etiam vitae dolor et mauris dapibus efficitur eget at neque. Cras malesuada convallis neque eu aliquam. Nunc luctus finibus odio, quis pellentesque dui facilisis a. Fusce tristique consequat eros quis tincidunt. Etiam eleifend maximus dui, sit amet ultrices lacus. Etiam vehicula ligula id mi consequat pulvinar et non odio. Ut felis felis, blandit et turpis non, vehicula aliquam augue. Sed libero eros, gravida quis accumsan vitae, pulvinar vitae felis. Maecenas cursus dignissim nibh quis posuere.
	    	</p>
	    	</div>

	    	<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Do you have a Business Query? Have an Online Chat with us!</h4>
	    	<h4 hide-gt-md style="color:#72012C">Do you have a Business Query? <br/> Have an Online Chat with us!</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Drop your Business Query</md-button>
				</div>
			</div>
			</div>
	    	
	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>