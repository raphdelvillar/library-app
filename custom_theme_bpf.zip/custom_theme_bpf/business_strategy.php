	<!--/* Template Name: Business_Strategy */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/business_strategy.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Business Strategy</h2>
	    	<p align="justify" class="md-body-1">
		    	<b>Business Partners Forum</b>, with its Innovative Business Strategy of <b>Connecting Business</b> by providing an <b>Online Business Platform</b>, and with its experienced team of <b>Business Consultants</b> and <b>Legal Attorneys</b>, offers a One Window Business Setup for Local Players who have either in business and needs to restructure and improve their business setup or for Entrepreneurs and Business Starters who wish to start Business Operations in Qatar.
		    	<br/><br/>
				With our <b>Years of Presence (More than 22 Years)</b> in Middle East/Qatar, we present the most unique Business Concept of Business Setup covering all aspects of operations fromRestructuring, Introduction of Company in the Business Market, HR & Recruitment Consultancy, Project Management, Social Media Marketing, and securing Business Leads for the Companies as per their core business activities.
				<br/><br/>
				We have Tie-ups with one of <b>top Law Firm, Shaikha Amna Al Thani</b>-Legal Consultants, who have a Legal Penal of <b>Top Attorneys</b> and <b>Lawyers</b> who are not giving their Legal Expertise in setting up the establishment of new business, but also making sure the entire legal process of either setting up of a new Business or any Legal changes in case of any changing in the company shareholders or other Legal Issues.
				<br/><br/>
				We do have experienced <b>HR Consultants</b>, who are seasoned and highly professionals with technical/operational experience of planning, creating, and executing the Business Setup from planning till execution when it comes to Business and Human Resources.
				<br/><br/>
				Our <b>Online Business Officers</b> with their sharp and business skillset are fully well versed not only to penetrate your <b>business activities for branding</b> in the Market using the Social Media and Other Advertisement Channels but also have contacts in the Business Sector to source Business Leads that matches your company’s portfolio.
				<br/><br/>
				Our <b>IT Team</b> is a highly Skilled Team that gives us an <b>Online Platform</b> in the form of a <b>highly Interactive website</b> with an <b>Online Database</b>, where both Business and Service Providing Community along with the Applicant/Freelances can communicate Only, can drop by their Company Details, Brochures, resumes with Online Business Interaction.
	    	</p>
	    	</div>

	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>