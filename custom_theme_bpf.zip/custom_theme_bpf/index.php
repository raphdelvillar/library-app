    <?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<!-- MASTER SLIDER -->
	    	<ul style="list-style: none; margin: 0; padding: 0; z-index: 2">
		    	<?php dynamic_sidebar( 'widgetmasterslider' ); ?>
		    </ul>

		    <!-- BUSINESS PHILOSOPHY -->
		    <div ng-cloak flex layout="column" id="business-philosophy" layout-align="center center" layout-xs="column" layout-sm="column" style="background-color:#FFFFFF">
			    <br/>
			    <div>
			      <h2 style="color:#72012C">Our Business Philosophy</h2>
			    </div>
			    <div layout="row">
			      <div flex="10"></div>
			      <div hide-xs hide-sm>
			        <center>
			        <img src="<?php echo get_template_directory_uri();?>/assets/logos/logo.png" width="162" height="100" class="img-circle" style="padding:15px;margin-top:15px"/>
			        </center>
			      </div>
			      <div flex="5" hide-xs hide-sm></div>
			      <div flex>
			          <p class="md-body-1" align="justify">
			            <b>Business Partners Forum</b> is a unique business platform to integrate both Business and Service Provider in an Interactive Online platform. It gives one Single Window for Business Community to Interact both as Business Provider or Service Provider.
			            <br/><br/>
			            <b>Our Mission and Objective</b> is to act as Business Partners for all business community from entrepreneurs and multinationals that wish to setup their business operations in Qatar to all service/business providers both International/Qatar based with Technical/Business support
			          </p>
			      </div>
			      <div hide-xs hide-sm flex="10"></div>
			      <div flex="5"></div>
			    </div>
			</div>
			<br/><br/>
			<!-- BULLETIN -->
			<div ng-cloak ng-controller="Bulletins" flex layout="row" id="bulletin" layout-xs="column" layout-sm="column" style="background-color:#FFFFFF">
			    <div hide-xs hide-sm flex="5"></div>
			    <div flex="45" flex-xs="100" flex-sm="100" layout-padding class="md-whiteframe-1dp left">
			        <h2 style="color:#FFFFFF">Our Latest</h2>
			        <md-divider style="border-color:#FFFFFF"></md-divider>
			        <div flex id="home_news" style="height: 200px; overflow: hidden">
			            <md-list>
			                <div ng-repeat="item in news">
			                   <div layout="row">
			                       <p class="md-body-1" flex style="color:#FFFFFF;font-size:75%">
			                         <b>{{item.subject}} :</b>
			                       </p>
			                       <div flex></div>
			                   </div>
			                   <p class="md-body-1" align="justify" flex style="color:#FFFFFF;font-size:75%">
			                       {{item.title}}
			                   </p>
			                   <div layout="row">
				                   <div flex></div>
				                   <p style="color:#FFFFFF;font-size:75%;cursor:pointer" ng-click="showAlert($event, item.subject, item.title, item.content)">
				                       <b>Read More...</b>
				                   </p>
			                   </div>
			                   <md-divider style="border-color:#FFFFFF"></md-divider>
			               </div>
			           </md-list>
			       </div>
			   </div>
			   <div ng-cloak flex="45" flex-xs="100" flex-sm="100" layout-padding class="md-whiteframe-1dp right">
			        <h2 style="color:#FFFFFF">News and Events</h2>
			        <md-divider style="border-color:#FFFFFF"></md-divider>
			        <div flex id="home_bulletin" style="height: 200px; overflow: hidden">
			            <md-list>
			                <div ng-repeat="item in bulletins">
			                    <div layout="row">
				                    <p class="md-body-1" flex="50" style="color:#FFFFFF;font-size:75%">
				                       <b>{{item.title}}</b>
				                   </p>
				                   <div flex></div>
				                   <div flex="15" ng-show="item.src1 != ''"><br/><img src="{{item.src1}}" class="md-avatar" width="75" height="50" style="margin-top:-10px"/></div>
				                   <div flex="5"></div>
				                   <div flex="15" ng-show="item.src2 != ''"><br/><img src="{{item.src2}}" class="md-avatar" width="75" height="50" style="margin-top:-10px"/></div>
				                   <div flex="5"></div>
			                   </div>
			                   <p align="justify" class="md-body-1" style="color:#FFFFFF;font-size:75%;white-space:pre-line" ng-bind-html="item.content"></p>
			                   <md-divider style="border-color:#FFFFFF"></md-divider>
			               </div>
			           </md-list>
			       </div>
			   </div>
			</div>
			<!-- OUR OFFICIAL PARTNERS -->
			<div ng-cloak flex ng-controller="Tinycarousel" style="background-color:#FFFFFF">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">Our Official Partners</h2>
			  </center>
			  <br/>
			  <center>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div flex="5"></div>
				    <div flex="65" class="partners">
				      <div ng-repeat="item in top">
				        <img src="{{item.src}}" height="200" width="200"/>
				      </div>
				    </div>
				    <div flex layout="column" style="border:1px solid #72012C">
				    	<p align="center" style="color:#72012C"><b>Outlook Group</b> - Contact Details</p>
				    	<div>
				    		<md-button download="outlook" href="<?php echo get_template_directory_uri();?>/assets/brochures/outlook.pdf" target="_blank" class="primary" style="background-color:#72012C;color:#FFFFFF">Download Brochure</md-button>
				    	</div>
				    	<div style="text-align:left" flex-offset="5">
				    		<p class="md-body-1">
	                			<i class="icon-contact fa-phone" style="color:#72012C"></i>
						    	&nbsp;&nbsp;&nbsp;+974 44366301
					    	</p>
					    	<p class="md-body-1">
		                		<i class="icon-contact fa-fax" style="color:#72012C"></i>
							    &nbsp;&nbsp;&nbsp;+974 44377605
					    	</p>
					    	<p class="md-body-1">
		                		<i class="icon-contact fa-envelope-o" style="color:#72012C"></i>
							    &nbsp;&nbsp;&nbsp;<a style="color:#000000;text-decoration-style:none" href="www.businesspartnersforum.com/contact-us">info@outlookgroup.com.qa</a>
					    	</p>
					    	<p class="md-body-1">
		                		<i class="icon-contact fa-inbox" style="color:#72012C"></i>
							    &nbsp;&nbsp;&nbsp;P.O.Box: 3129, Doha-Qatar
					    	</p>
				    	</div>
				    </div>
				    <div flex="5"></div>
			    </div>
			    <br/>
			  </center>
			  <script type="text/javascript">
			    $(document).ready(function(){
			      $('.partners').slick({
			        dots: true,
			        infinite: true,
			        speed: 700,
			        autoplay:true,
			        autoplaySpeed: 2000,
			        arrows:true,
			        slidesToShow: 4,
			        slidesToScroll: 1,
			        responsive: [
			        {
			          breakpoint: 1024,
			          settings: {
			            slidesToShow: 3,
			            slidesToScroll: 3,
			            infinite: true,
			            dots: true
			          }
			        },
			        {
			          breakpoint: 600,
			          settings: {
			            slidesToShow: 2,
			            slidesToScroll: 2,
			            dots: false
			          }
			        },
			        {
			          breakpoint: 480,
			          settings: {
			            slidesToShow: 1,
			            slidesToScroll: 1,
			            dots: false
			          }
			        }
			        ]
			      });
			    });
			  </script>
			</div>

			<!-- BPF AT A GLANCE -->
			<div ng-cloak flex style="background-color:#FFFFFF">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">BPF At A Glance</h2>
			  </center>
			  <br/>
			  <div layout="column" layout-padding>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div hide-xs hide-sm flex="10"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Outsourcing/Headhunting</b>
				        <p align="justify" class="md-body-1">
				          Outsourced Partners for our clients for Corporate, Executive, Business, Operational, Technical, Office Staff to be on board through our Top of the Line professional team. 
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Recruitment/Manpower</b>
				        <p align="justify" class="md-body-1">
				          Full Spectrum of Recruitment, manpower for more than 10,000 Corporate/Operational Staff and above 35,000 skilled workforce deployments in the entire GCC including Qatar.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
			  			<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Web Media</b>
				        <p align="justify" class="md-body-1">
				          Complete web solutions from Domain Registration/Hosting to Email configurations, Responsive Websites, SEO Management, Web Hosting, Web based online business tools.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  	</div>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div hide-xs hide-sm flex="10"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Digital Media</b>
				        <p align="justify" class="md-body-1">
				          Having our own Printing Press and In-house creative team, we offer complete Digital solutions from Banners, Flyers, Stickers, Catalogues, Brochures, Business Cards and all advertising material.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Local Sponsorship</b>
				        <p align="justify" class="md-body-1">
				          Full Spectrum of business assistance & company establishment in Qatar from Local Sponsors, Lawyers, Offices, Logistics, Governmental Approvals, bank accounts, tax cards to acquiring all Company Licenses.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
			  			<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Legal Attorneys</b>
				        <p align="justify" class="md-body-1">
				          Partners of Shaikha Amna Al Thani- Legal Barristers/Law Firm, with Legal Consultant services from Courts-(Civil/Criminal/Employee-Sponsor Conflicts to Corporate Company Lawyers and legal consultants.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  	</div>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div hide-xs hide-sm flex="10"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> JV Partners</b>
				        <p align="justify" class="md-body-1">
				          Value addition to Qatar’s Business Industry through our International/Local Business Affiliates with strong presence in Qatar, we are committed to welcome JV Partners from any industry for business.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Business Setup</b>
				        <p align="justify" class="md-body-1">
				          Strengthening your Business either as a starter/add-on in existing business with your pre/post launching.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
			  			<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Social Media Ads</b>
				        <p align="justify" class="md-body-1">
				          Let us connect you to your clients and be on Top of Business through our Social Media advanced Solution.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  	</div>
			  	<div layout="row" layout-xs="column" layout-sm="column">
			  		<div hide-xs hide-sm flex="10"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> General Contracting</b>
				        <p align="justify" class="md-body-1">
				          From (Project/Cost Planning), (B.I.M), (Civil/MEP), (Finishing) till hand over to Client as (Design & Build). 
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
				  		<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Catering</b>
				        <p align="justify" class="md-body-1">
				          With over 100 Professional Chef/Cooks and presence in Market for 12 years, we have blend of Asian/Arabic Cuisine for Parties/Offices/Labor Camps. Competitive rates with delicious taste.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  		<div flex="25" flex-xs="90" flex-sm="90">
			  			<b style="color:#72012C"><i class="fa fa-th-list" aria-hidden="true"></i> Fleet Operations</b>
				        <p align="justify" class="md-body-1">
				          From Buses, Coasters, Rent a Car to Limousine Service with a total fleet of above 400 Vehicles, we offer the best fleet services across the Country through our professional operational staff and trained drivers.
				        </p>
			  		</div>
			  		<div hide-xs hide-sm flex="5"></div>
			  	</div>
			  </div>
			</div>

			<!-- OUR SERVICES -->
			<div ng-cloak flex style="background-color:#FFFFFF" layout-align="center center">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">Our Services</h2>
			  </center>
			  <?php include "pages/simple-portfolio-page/index.html"; ?>
			</div>

			<!-- OUR AFFILIATES/CLIENTS -->
			<div ng-cloak flex ng-controller="Tinycarousel" style="background-color:#FFFFFF">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">Our Affiliates/Clients</h2>
			  </center>
			  <br/>
			  <center>
			    <div style="width: 75%" class="clients">
			      <div ng-repeat="item in bottom">
			        <a href="{{item.link}}" target="_blank"><img src="{{item.src}}" height="200" width="200"/></a>
			      </div>
			    </div>
			    <br/>
			  </center>
			  <script type="text/javascript">
			    $(document).ready(function(){
			      $('.clients').slick({
			        dots: true,
			        infinite: true,
			        speed: 700,
			        autoplay:true,
			        autoplaySpeed: 2000,
			        arrows:true,
			        slidesToShow: 4,
			        slidesToScroll: 1,
			        responsive: [
			        {
			          breakpoint: 1024,
			          settings: {
			            slidesToShow: 3,
			            slidesToScroll: 3,
			            infinite: true,
			            dots: true
			          }
			        },
			        {
			          breakpoint: 600,
			          settings: {
			            slidesToShow: 2,
			            slidesToScroll: 2,
			            dots: false
			          }
			        },
			        {
			          breakpoint: 480,
			          settings: {
			            slidesToShow: 1,
			            slidesToScroll: 1,
			            dots: false
			          }
			        }
			        ]
			      });
			    });
			  </script>
			</div>

			<!-- OUR BUSINESS VENTURES -->
			<div ng-cloak flex style="background-color:#FFFFFF">
			  <br/><br/>
			  <center>
			  <h2 style="color:#72012C">Our Business Ventures</h2>
			  <ul style="list-style:none;margin:0;padding:0;color:#FFFFFF">
			  	<?php echo dynamic_sidebar( 'widgetinstagramfeed' ); ?>
			  </ul>
			  </center>
			</div>

			<!-- FOOTER -->
			<?php include "index_footer.php" ?>

	    </div>
    </div>
  <?php get_footer(); ?>