	<!--/* Template Name: Business_Setup */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/business_setup.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Business Setup</h2>
	    	<p align="justify" class="md-body-1">
		    	Been in International & GCC Business Industry for almost 20 years and having a strong base in Qatar along with our Business/Service Partners & Affiliates, BPF is committed to offer <b>One Window</b> ‘Business Setup’ that covers the entire spectrum for Entrepreneurs from their Business thought, Concept till it comes to a reality for Establishment of a Business Entity as a Company.
		    	<br/><br/>

				•	All Administrative, Legal, Public Relations activities.<br/><br/>
				•	Registration of Company name, Official Logo.<br/><br/>
				•	Provision of Qatari Sponsors.<br/><br/>
				•	Banking Approvals for Company Accounts.<br/><br/>
				•	Provision of Office Space (Temporary/Permanent).<br/><br/>
				•	Functional Administrative Staff<br/><br/>
				•	Provision of Qatari Sponsors.<br/><br/>
				•	Company Registration License.<br/><br/>
				•	Computer Card.<br/><br/>
				•	Municipality Approvals/Licenses.<br/><br/>
				•	Tax Card.<br/><br/>
				•	Domain Registration/Company Emails/Websites.<br/><br/>
				•	Online Web based Marketing<br/><br/>
				•	Business Development<br/><br/>
	    	</p>
	    	</div>

	    	<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Do you have a Business Query? Have an Online Chat with us!</h4>
	    	<h4 hide-gt-md style="color:#72012C">Do you have a Business Query? <br/> Have an Online Chat with us!</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Drop your Business Query</md-button>
				</div>
			</div>
			</div>
	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>