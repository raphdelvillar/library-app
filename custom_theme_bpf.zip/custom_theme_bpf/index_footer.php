<div ng-cloak style="background-color:#9E1C37;color:#ffffff;position:relative;opacity: 0.95">
  <center>
  <table hide-gt-md layout-padding>
    <tr>
      <td><i class="icon-contact fa-phone" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">+974 4498 0376</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-inbox" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">PO Box 3129, Doha-Qatar</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-fax" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">+974 4437 7605</span></td>
    </tr>
    <tr>
      <td><i class="icon-contact fa-envelope-o" style="font-size:75%;color:#FFFFFF"></i></td>
      <td><span style="font-size:75%" flex-offset="5">info@businesspartnersforum.com</span></td>
    </tr>
  </table>
  </center>
  <div ng-cloak hide-xs hide-sm layout="row" layout-xs="column" layout-sm="column" flex>
    <div flex-offset="10" flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-phone" style="color:#FFFFFF"></i>
      <span flex-offset="5">+974 4498 0376</span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-inbox" style="color:#FFFFFF"></i>
      <span flex-offset="5">PO Box 3129, Doha - Qatar</span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-fax" style="color:#FFFFFF"></i>
      <span flex-offset="5">
      +974 4437 7605
      </span>
      </p>
      </center>
    </div>
    <div flex="20" flex-xs="100" flex-sm="100">
      <center>
      <p style="font-size:75%;color:#FFFFFF">
      <i class="icon-contact fa-envelope-o" style="color:#FFFFFF"></i>
      <span flex-offset="5">
      info@businesspartnersforum.com
      </span>
      </p>
      </center>
    </div>
  </div>
</div>
<div show-md show-gt-md style="background-color:#000000;color:#ffffff;position:relative;">
  <div layout="row" layout-xs="column" layout-sm="column" flex>
    <div flex="75" flex-xs="100" flex-sm="100">
      <center>

        <marquee loop="true" direction="left" scrollamount="2" class="footer">
          <p style="font-size:75%;color:#FFFFFF">
            <img style="vertical-align:middle" src="<?php echo get_template_directory_uri();?>/assets/qatar-flag.jpg" alt="flag" width="32"/> 
            Together, We Serve Better
          </p>
        </marquee>  

      </center>
    </div>
    <div flex>
      <center>
        <p style="color:#FFFFFF" class="md-body-1">&copy businesspartnersforum 2017</p>
      </center>
    </div>
  </div>
</div>