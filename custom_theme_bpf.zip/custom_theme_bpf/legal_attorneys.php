	<!--/* Template Name: Legal_Attorneys */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/legal_attorneys.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Legal-Law Partners</h2>
	    	<p align="justify" class="md-body-1">
		    	We have Tie-ups with one of <b>Top Law Firm, Shaikha Amna Al Thani</b>-Legal Consultants, with a Legal Penal of <b>Top Attorneys</b> and <b>Lawyers</b> who are not giving their Legal Expertise in setting up the establishment of new business, but also making sure the entire legal process of either setting up of a new company establishment or any Legal changes (Existing Company Shareholders-if any).
		    	<br/><br/>
				<b>Services Offered:</b><br/><br/>
				•	Legal representatives of a Company.<br/><br/>
				•	Criminal Cases.<br/><br/>
				•	Civil Cases.<br/><br/>
				•	Employer/Employee Conflicts.<br/><br/>
				•	Legal Documentations.<br/><br/>
				•	Deportation/Runaway/Black List Legal Cases.<br/><br/>
	    	</p>
	   		<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Do you have a Business Query? Have an Online Chat with us!</h4>
	    	<h4 hide-gt-md style="color:#72012C">Do you have a Business Query? <br/> Have an Online Chat with us!</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Drop your Business Query</md-button>
				</div>
			</div>
			</div>
	    	</div>

	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>