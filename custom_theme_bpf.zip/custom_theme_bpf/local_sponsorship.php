	<!--/* Template Name: Local_Sponsorship */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/local_sponsorship.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-padding>
	    	<center><h2 style="color:#72012C">Local Sponsorship</h2></center>
	    	<md-tabs md-dynamic-height md-border-bottom>
	    		<md-tab label="Services by BPF">
					<div style="background-color:#FFFFFF" layout-padding>
						<h3 style="color:#72012C">Services by BPF</h3>
						<p align="justify" class="md-body-1">
						•	Provision of Complete Local Sponsorship Solutions from Concept till establishment. 
						<br/><br/>
						•	Provision of Qatari Sponsors.
						<br/><br/>
						•	Top of the Line Legal Consultants. (Shaikha Amna Al Thani-Barrister Law Associates)
						</p>
					</div>
				</md-tab>
				<md-tab label="Local Sponsorship">
					<div style="background-color:#FFFFFF" layout-padding>
						<h3 style="color:#72012C">Legal Structures for Local Sponsorship</h3>
						<p align="justify" class="md-body-1" style="white-space: pre-line;">The Qatari Laws stipulate a total local equity of not less than 51% in any commercial company and defines seven categories of business organization, which can be established in Qatar except for those categories mentioned in Law 13 of 2000 and Law 1 of 2010. 

							It sets out the requirements in terms of shareholders, directors, minimum capital levels and incorporation procedures. 

							The seven categories of business organization defined by the Law are:
						</p>
					</div>
					<br/><br/>
					<ul class="collapsible popout" data-collapsible="accordion" style="list-style-type: none;padding: 0;margin:0;background-color: #ffffff">
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Simple Partnership Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									It is the most basic form of commercial arrangement for two or more individuals to associate
									for having a commercial activity in Qatar. 
									<br/><br/>
									The partners have unlimited liability and the trade
									name of the partnership company will reflect the names of the partners.
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Joint Partnership Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									Is like a simple partnership company however, a joint partnership company will have two
									classes of partners. 
									<br/><br/>
									1- Joint Partners. 
									<br/>
									2- Trustee Partners.
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Joint Venture Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									It is an entity comprised of two or more persons that associate to carry out a project. 
									<br/><br/>
									The joint venture company provided for in the law is an unincorporated entity without legal personality.
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Public Shareholding Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									The public shareholding company is also known as a joint stock company or Qatari shareholding
									company. 
									<br/><br/>
									The law recognizes different variants of the public shareholding company including:
									<br/><br/>
									1- Public shareholding company-open. <br/>2- Private or closed public shareholding company.
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Limited Share Partnership Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									It has at least one or more joint partners and at least four trustee shareholding partners. 
									<br/><br/>
									The minimum share capital of the company is <b>1,000,000 QAR</b>
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Limited Liability Company</b></center>
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									It is the most commonly used business entity in Qatar normally registered as <b>(W.L.L)</b>
								</p>
							</div>
						</li>
						<md-divider style="color:#404041"></md-divider>
						<li>
							<div layout-padding class="collapsible-header md-whiteframe-1dp" style="color:#ffffff; background-color:#9E1C37;cursor:pointer;">
								<center><b>Holding Companies</b></center> 
							</div>
							<div layout-padding class="collapsible-body md-whiteframe-1dp" style="background-color: #ffffff">
								<p align="justify" class="md-body-1">
									It is a holding company which must be a shareholding company or limited liability company and
									which has financial and management control on the companies by owning at least 51% of that
									company. 
									<br/><br/>
									The minimum capital should be 10 million QR.
								</p>
							</div>
						</li>
					</ul>
					<br/>
					<div layout-padding>
						<p class="md-body-1">
							Out of these seven structures, (W.L.L) is more commonly used by the foreign investors.	
						</p>
					</div>
				</md-tab>
				<md-tab label="Qatar as a Business Hub">
					<div style="background-color:#FFFFFF" layout-padding>
						<h3 style="color:#72012C">Qatar as a Business Hub</h3>
						<p align="justify" class="md-body-1" style="white-space: pre-line;">
							<b>Qatar</b> is the wealthiest country in the world in per capita terms with substantial oil and gas reserves, an excellent infrastructure system and free market economic policies. As a member of the World Trade Organization (WTO) and other international financial bodies, Qatar offers investors a mature and sophisticated banking environment. Qatar&#39;s economy has been growing by around 10% per year in recent years. The Foreign Investment Law No.13 of 2000 has also played an important role in stimulating economic growth. The law permitted up to 100% foreign ownership for the first time in the sectors of agriculture, manufacturing, health, education, and tourism. It also offered investors many substantial incentives, including the freedom to repatriate all profits to the investor’s country of origin.
						</p>
						<p align="justify" class="md-body-1" style="white-space: pre-line;">
							<b>Qatar’s</b> economic development strategy has been very successful and the investment incentives, infrastructure, banking services, insurances and political and social stability are contributing factors in creating an excellent business climate for Entrepreneurs and start-ups
						</p>	
						<p align="justify" class="md-body-1" style="white-space: pre-line;">
							<b>International Business Players</b> with a plan to establish their commercial presence in Qatar, there are a few (Company Establishment), setup options with the most common being the <b>LLC ( Limited Liability Company)</b> where the <b>Entity</b> must have one or more national partners whose share in the company capital must not be less than <b>51%</b>. Here must be noted that the parties&#39; profit share does not necessarily have to reflect their equity stake. Therefore, foreign investors wishing to establish business operations in Qatar engaged in most of the commercial business activities must do so with a Partner who shall be a <b>Qatari National</b>.
						</p>	
					</div>
				</md-tab>
				<md-tab label="Company Formation Steps">
					<div style="background-color:#FFFFFF" layout-padding>
						<h3 style="color:#72012C">Steps to be followed in the registration of a Qatar company</h3>
						<p align="justify" class="md-body-1">
							Identifying the appropriate Qatari national as partner or if the case the preparation and follow up of required documentation &amp; processing application for 100% owned business at the Ministry of Business and Trade
						</p>
						<p align="justify" class="md-body-1">Obtaining name approval for new company.</p>
						<p align="justify" class="md-body-1">Obtaining activity approval for new company.</p>
						<p align="justify" class="md-body-1">Bank Account opening with the minimum share capital of <b>QAR 200,000</b>.</p>
						<p align="justify" class="md-body-1">Preparation of the Articles of the Association for the company.</p>
						<p align="justify" class="md-body-1">
							Processing necessary documentation and assisting in the attestations from the Ministry of Justice.
						</p>
						<p align="justify" class="md-body-1">
							Preparation of necessary documentation &amp; Processing Application for registration with the Chamber of Commerce.
						</p>
						<p align="justify" class="md-body-1">
							Preparing documentation &amp; processing the application for Company Registration with the Ministry of Business &amp; Trade.
						</p>
						<p align="justify" class="md-body-1">
							Preparing the documentation &amp; processing the Application for Municipality License.
						</p>
						<p align="justify" class="md-body-1">
							Preparing the documentation &amp; Processing Application for Immigration Card for the Company.
						</p>
						<p align="justify" class="md-body-1">
							Once the company has been incorporated and the Commercial Registration issued, the share capital can be released to the company’s directors or the general manager for the purposes of running the company.
						</p>
					</div>
				</md-tab>
				<md-tab label="FAQ">
					<div style="background-color:#FFFFFF" layout-padding>
						<h3 style="color:#72012C">Frequently Asked Questions</h3>
						<h4 style="color:#9E1C37">What timeframe should be considered when incorporating a Qatar company?</h4>
						<p align="justify" class="md-body-1">
							<b>BPF</b> Consulting can complete the company registration process within two to three weeks.
						</p>

						<h4 style="color:#9E1C37">What are the requirements for setting up a LLC (W.L.L) in Qatar?</h4>
						<p align="justify" class="md-body-1">
							The Ministry of Economy and Commerce in Doha should approve the company name. The signed Memorandum and Articles of Association in Arabic should be submitted to the Ministry of Economy and Commerce. Furthermore, the minimum required capital sshould be deposited into a local Qatari bank.
						</p>

						<h4 style="color:#9E1C37">What is the minimum number of directors/shareholder required for a Qatar Company?
						</h4>
						<p align="justify" class="md-body-1">
							A Qatar Company requires a minimum of 2 shareholders and 1 director.
						</p>

						<h4 style="color:#9E1C37">Are there any restrictions on ownership of a Qatar Company?</h4>
						<p align="justify" class="md-body-1">
							For a Limited Liability Company (LLC), foreign investors are permitted up to 49% of the stake if there are one or more Qatari partners. It is also possible for foreigners to own up to 100% of a Qatar company upon request in specialist sectors: agriculture, industry, health, education, tourism and development of natural resources, consultancy services, information technology (IT), services related to sports, culture, and entertainment as well as distribution services.
						</p>

						<h4 style="color:#9E1C37">What are the requirements for setting up a LLC in Qatar?</h4>
						<p align="justify" class="md-body-1">
							The Ministry of Economy and Commerce in Doha should approve the company name. The signed Memorandum and Articles of Association in Arabic should be submitted to the Ministry of Economy and Commerce. Furthermore, the minimum required capital should be deposited into a local Qatari bank.
						</p>

						<h4 style="color:#9E1C37">Is a Qatar Company subject to an annual audit?</h4>
						<p align="justify" class="md-body-1">
							A Qatar LLC is required to submit an annual tax return. If annual profits exceed <b>100,000 QAR</b> the declaration should be accompanied by audited financial statements prepared by an auditor registered in Qatar.
						</p>

						<h4 style="color:#9E1C37">What are the minimum capital requirements for a Qatar Company?</h4>
						<p align="justify" class="md-body-1">
							A Qatar L.L.C. requires a minimum capital of <b>200,000 QAR</b>.
						</p>

						<h4 style="color:#9E1C37">What are the tax implications of a Qatar Company formation?</h4>
						<p align="justify" class="md-body-1">
							A Qatar LLC is liable to pay a corporate income tax of <b>10</b> % on profits sourced in Qatar.
						</p>

						<h4 style="color:#9E1C37">What is the governing Law for commercial contracts in Qatar?</h4>
						<p align="justify" class="md-body-1">
							Once a business entity has been established it will need to protect its interests when contracting with other entities. The parties to an international contract are free to choose the law and authority which will govern that contract. (If they do not choose an applicable law, the Qatari Civil Code will govern the contract.)
						</p>
					</div>
				</md-tab>
			</md-tabs>

			<script>
				$(document).ready(function(){
					$('.collapsible').collapsible();
				});
			</script>

	    	</div>

	    	<div layout-align="center center" layout="column" layout-padding>
	    	<h4 hide-xs hide-sm style="color:#72012C">Do you have a Business Query? Have an Online Chat with us!</h4>
	    	<h4 hide-gt-md style="color:#72012C">Do you have a Business Query? <br/> Have an Online Chat with us!</h4>
	    	<div layout="row" layout-xs="column" layout-sm="column">
	    		<script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
				<div id="SkypeButton_Call_bpfqatar_1">
				 <script type="text/javascript">
				 Skype.ui({
				 "name": "chat",
				 "element": "SkypeButton_Call_bpfqatar_1",
				 "participants": ["live:bpfqatar"],
				 "imageSize": 24
				 });
				 </script>
				</div>
				<div>
					<md-button href="www.businesspartnersforum.com/contact-us" class="primary" style="background-color:#72012C;color:#FFFFFF;margin-top:35px">Drop your Business Query</md-button>
				</div>
			</div>
			</div>
	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>