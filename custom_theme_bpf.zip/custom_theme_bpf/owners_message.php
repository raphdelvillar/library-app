	<!--/* Template Name: Owners_Message */-->
	<?php get_header(); ?>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/style/index.css">
	    <div layout="column" flex="100" layout-fill layout-align="center center" style="display:block;background-color:#EEEEEE">

	    	<!-- HEADER -->
	    	<?php get_sidebar(); ?>

	    	<img src="<?php echo get_template_directory_uri();?>/assets/banners/owners_message.jpg" width="100%" style="border-bottom: 2px solid #72012C"/>

	    	<div layout="column" layout-align="center center" layout-padding>
	    	<h2 style="color:#72012C">Owner's Message</h2>
	    	<p align="justify" class="md-body-1">
		    	I appreciate that you have taken a few moments to visit BPF’s website and explore more about our Business Vision and the Corporate team involved in giving their best to the Industry. As owner of BPF, and along with my valued team, we have been doing at our best to connect the Business with the Service Industry in Middle East and in the International Business Sector.
		    	<br/><br/>
				Whether you are exploring our Website as a Client, a Service Provider, Applicant, or a Freelancer, we welcome you to get an idea about one of the most unique business platform being introduced by BPF to serve the nation and business community by bringing One Window Business Solutions at Client’s fingertips.
				<br/><br/>
				Ever since my presence in Middle East and International Sector for more than 22 years, while dealing with Top Business Owners, Corporate CEOs, Key Strategic Partners for both Public and Private Sector and by giving value additions to Multiple Business Industries from Contracting, Facility Management, Automobiles, Hospitality, Healthcare, FMCG, Retail, Shipping to Corporate Sector, I launched BPF to collectively provide a Platform where Service Providers worldwide can serve with BPF based on their core services.  Today, the Group with a clear vision and a dynamic team has managed to be one of the major business address in Qatar for its unique Online Business Solutions to any business industry in Qatar. We are proud to be in the Qatar’s Business Sector, reflecting the desire to contribute to the development of the country. We intend to extend our services across the region and to forge strategic partnerships with International Companies.
				<br/><br/>
				I also invite the Professionals from Qatar/Middle East and worldwide to join us as Online Business Officers or Freelancers to give their technical expertise to BPF clients using our Platform.
				<br/><br/>
				I welcome also all Service Providers worldwide (Recruitment/Outsourcing agencies, Contracting and other Sub-Contractors, I.T/any other service that they can render to our clients as our valued JV-Partners-Service Sector)
				Once again, I welcome you to our website and I believe that you find it informative and helpful and we are here to serve you better and in a professional way.
				<br/><br/>
				<b>Aamir Khan</b>  
	    	</p>
	    	</div>

	    	<!-- FOOTER -->
	    	<?php include "index_footer.php" ?>
	    </div>
	</div>
	<?php get_footer(); ?>