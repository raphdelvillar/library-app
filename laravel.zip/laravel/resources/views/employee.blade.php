<h2>Greetings Mr.Khan!</h2>

<p>
<b>User reply: </b>
<br/><br/>
{{ $content }}

<br/><br/>
Together, We Serve Better

<br/><br/>
Regards,<br/>
<b>{{ $name }}</b>
