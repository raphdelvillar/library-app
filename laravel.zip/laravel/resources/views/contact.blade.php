<h2>Greetings {{ $name }}!</h2>

<p>
We are <b>Business Partners Forum.</b>
<br/><br/>
{{ $content }}
<br/><br/>
Together, We Serve Better

<br/><br/>
Regards,<br/>
<b>Business Partners Forum</b>
<br/><br/>
<img src="{{ $signature }}"/>
</p>
