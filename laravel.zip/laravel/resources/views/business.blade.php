<h2>Greetings {{ $name }}!</h2>

<p>
We are <b>Business Partners Forum.</b>
<br/><br/>
We thank you and acknowledge your registration and submission of your company details through our website.
<br/>
We are glad to have your company profile as our valued service partner.
<br/><br/>
We will contact you accordingly with the best service provider as our JV Partner to support your Business/Project requirements.
<br/><br/>
We hope that we will have a fruitful partnership.
<br/><br/>
For more information, please visit <a href="www.businesspartnersforum.com">www.businesspartnersforum.com</a>.
Thank you again for your interest.

<br/><br/>
Together, We Serve Better

<br/><br/>
Regards,<br/>
<b>Business Partners Forum</b>
<br/><br/>
<img src="{{ asset('img/aamir_khan.jpg') }}"/>
</p>
