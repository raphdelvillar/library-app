<h2>Greetings <?php echo e($name); ?>!</h2>

<p>
We are <b>Business Partners Forum.</b>
<br/><br/>
We have received your application for employment opportunities at Business Partners Forum and are in the process of reviewing your qualifications against our current requirements. 
<br/><br/>
Should your background and experience meet the requirements of one of our job openings, we will contact you to request addition information. 
<br/><br/>
For more information, please visit <a href="www.businesspartnersforum.com">www.businesspartnersforum.com</a>.
Thank you for contacting <b>Business Partners Forum</b>.

<br/><br/>
Together, We Serve Better

<br/><br/>
Regards,<br/>
<b>Business Partners Forum</b>
<br/><br/>
<img src="<?php echo e(asset('img/aamir_khan.jpg')); ?>"/>
</p>
