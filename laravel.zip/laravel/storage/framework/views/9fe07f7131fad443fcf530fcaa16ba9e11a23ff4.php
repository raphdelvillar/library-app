<h1>Hi, <?php echo e($name); ?></h1>
<p>Thank you for your application.</p>
