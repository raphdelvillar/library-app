<h2>Greetings Mr.Khan!</h2>

<p>
<b>User reply: </b>
<br/><br/>
<?php echo e($content); ?>


<br/><br/>
Together, We Serve Better

<br/><br/>
Regards,<br/>
<b><?php echo e($name); ?></b>
