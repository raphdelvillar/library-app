<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*
Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:api');
*/

/**LOGIN**/
Route::post('login', array('uses' => 'LoginController@doLogin'));
Route::post('register/checkmail', array('uses' => 'LoginController@checkEmail'));

/**REGISTER**/

/**APPLICANT/FREELANCER**/
Route::post('applicants/register', array('uses' => 'ApplicantController@registerApplicant'));
Route::post('applicants/uploadcv', array('uses' => 'ApplicantController@registerApplicant_UploadCV'));
Route::post('applicants/uploadphoto', array('uses' => 'ApplicantController@registerApplicant_UploadPhoto'));

Route::post('applicants/getapp', array('uses' => 'ApplicantController@getApplicants'));
Route::post('applicants/getfre', array('uses' => 'ApplicantController@getFreelancers'));

Route::post('applicants/appcontact', array('uses' => 'ApplicantController@contactApplicants'));

/**BUSINESS PROVIDER**/
Route::post('bp/register', array('uses' => 'BusinessProviderController@registerBusinessProvider'));
Route::post('bp/uploadbrochure', array('uses' => 'BusinessProviderController@registerBusinessProvider_UploadBrochure'));

Route::post('bp/get', array('uses' => 'BusinessProviderController@getBusinessProviders'));
Route::post('bp/contact', array('uses' => 'BusinessProviderController@contactBusinessProvider'));
/**SERVICE PROVIDER**/
Route::post('sp/register', array('uses' => 'ServiceProviderController@registerServiceProvider'));
Route::post('sp/uploadbrochure', array('uses' => 'ServiceProviderController@registerServiceProvider_UploadBrochure'));
Route::post('sp/uploadphoto', array('uses' => 'ServiceProviderController@registerServiceProvider_UploadPhoto'));
Route::post('sp/get', array('uses' => 'ServiceProviderController@getServiceProviders'));
Route::post('sp/contact', array('uses' => 'ServiceProviderController@contactServiceProvider'));
/**ADMIN**/
Route::post('admins/contract', array('uses' => 'AdminController@contractAction'));
Route::post('admins/uploadsignatures', array('uses' => 'AdminController@Admins_UploadSignature'));

Route::post('admins/get', array('uses' => 'AdminController@getAdmins'));
Route::post('admins/add', array('uses' => 'AdminController@addAdmins'));
Route::post('admins/delete', array('uses' => 'AdminController@deleteAdmins'));
Route::post('admins/changepw', array('uses' => 'AdminController@changePasswordAdmins'));
/**TEST**/
/*
Route::get('hashify', array('uses' => 'AdminController@hashify'));
*/

/**BULLETIN**/
Route::post('bulletin/getBulletin', array('uses' => 'BulletinController@getBulletin'));
Route::post('bulletin/add', array('uses' => 'BulletinController@addBulletin'));
Route::post('bulletin/update', array('uses' => 'BulletinController@updateBulletin'));
Route::post('bulletin/delete', array('uses' => 'BulletinController@deleteBulletin'));
Route::post('bulletin/uploadphoto', array('uses' => 'BulletinController@uploadBulletinPhoto'));

