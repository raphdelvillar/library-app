<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EmailController; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class BusinessProviderController extends BaseController
{

	/*Business Provider Registration*/
	public function registerBusinessProvider(){
		try{
			DB::table('businessproviders')->insert([
				'name' => Input::get('name'),
				'country' => Input::get('country'),
				'sector' => Input::get('sector'),
				'others' => Input::get('others'),
				'bio' => Input::get('bio'),
				'landline' => Input::get('landline'),
				'mobile' => Input::get('mobile'),
				'website' => Input::get('website'),
				'contact' => Input::get('contact'),
				'brochure' => Input::get('brochure'),
				'referral' => Input::get('referral'),
				'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
			]);

			$id = DB::getPdo()->lastInsertId();
			$password = Input::get('password');
			$password = Hash::make($password);
			DB::table('users')->insert([
				'username' => Input::get('username'),
				'password' => $password,
				'usertype' => Input::get('type'),
				'infoID' => $id,
				'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
			]);

			$sendmail = new EmailController;
            $subject = '[Business Partners Forum] Welcome to Business Partners Forum!';
            $sendmail->sendmail('business', $name, $email, 'business@businesspartnersforum.com', 'Business Partners Forum', $subject, '');

		}catch(Exception $e){

		}
	}

	public function registerBusinessProvider_UploadBrochure(Request $request){
		try{
			$dir = __DIR__ . '/../../../uploads/employers/business_providers/brochure';
			$rand = $this->generateRandomString();
			$filename = $rand . '_' . $request->file('file')->getClientOriginalName();
			while(file_exists($dir . $filename)){
				$rand = $this->generateRandomString();
				$filename = $rand . '_' . $request->file('file')->getClientOriginalName();
			}

			$request->file('file')->move($dir, $filename);

			$url = url('/') . '/../uploads/employers/business_providers/brochure/';
			return $url. $filename;
		}catch(Exception $e){

		}
	}

	private function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    /* Get Business Provider */
    public function getBusinessProviders(){
    	try{
    		$businessproviders = DB::table('users')
    							->join('businessproviders','users.infoID','=','businessproviders.id')
    							->where('users.usertype','=', 'Business Provider')
    							->get();

    		return json_encode($businessproviders);
    	}catch(Exception $e){

    	}
    }

    /* Contact Business Provider */
    public function contactBusinessProvider(){
        try{
            $admin = DB::table('admins')
                     ->where('id', Input::get('id'))
                     ->first();

            $array = array();
            $array['name'] = Input::get('name');
            $array['emailto'] = Input::get('emailto');
            $array['email'] = $admin->email;
            $array['emailfromname'] = $admin->username;
            $array['subject'] = '[Business Partners Forum]' . Input::get('subject');
            $array['content'] = Input::get('content');
            $array['signature'] = $admin->signature;

            $sendmail = new EmailController;
            $sendmail->contactmail($array);
        }catch(Exception $e){

        }
    }

	/* select freelancer/applicant */
	/*
	public function businessproviderjobseekers(){
		try{
			$jobseekers = DB::table('users')
    						   ->join('serviceproviders', 'users.infoID', '=', 'serviceproviders.id')
    						   ->get();

    		return json_encode($jobseekers);
		}catch(Exception $e){

		}
	}
	*/

	/* select joborder */
	/*
	public function businessproviderjoborder(){
		try{
			$user = Input::get('userID');
			$joborders = DB::table('jobs')
						->where('userID', '=', $user)
						->get();

			return json_encode($joborders);
		}catch(Exception $e){

		}
	}
	*/

	/* new joborder */
	/*
	public function businessprovideraddjoborder(){
		try{
			DB::table('jobs')->insert([
                'position' => Input::get('position'),
                'category' => Input::get('category'),
                'others' => Input::get('others'),
                'description' => Input::get('description'),
                'userID' => Input::get('userID'),
        	]);

        	return "success";
		}catch(Exception $e){

		}
	}
	*/

}

?>