<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EmailController; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class AdminController extends BaseController
{
	public function contractAction(){
		try{
			$id = Input::get('id');
			$answer = Input::get('answer');
			$content = Input::get('message');

			DB::table('admins')
				->where('id', $id)
				->update(['contract' => $answer]);

			$users = DB::table('admins')->where('id', $id)->first();
			$sendmail = new EmailController;
	        $subject = '[Business Partners Forum][Official Contract] ' . $users->username . ' responded ' . $answer;
	        $sendmail->sendmail('employee', $users->username, 'khan@businesspartnersforum.com', $users->email, $users->username, $subject, $content);

	        return json_encode($users);
		}catch(Exception $e){

		}
	}

	private function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

	public function Admins_UploadSignature(Request $request){
        try{
            //var_dump($request->file('file')->getClientOriginalName()); 
            $dir = __DIR__ . '/../../../uploads/admins/signatures';
            $rand = $this->generateRandomString();
            $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            while(file_exists($dir . $filename)){
                $rand = $this->generateRandomString();
                $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            }

            $request->file('file')->move($dir, $filename);

            $url = url('/') . '/../uploads/admins/signatures/';
            return $url . $filename;   
        }catch(Exception $e){

        }
    }

	public function getAdmins(){
		try{
			$admin = DB::table('admins')->get();
			return json_encode($admin);
		}catch(Exception $e){

		}
	}

	public function changePasswordAdmins(){
		try{
			$password = Input::get('password');
			$password = Hash::make($password);
			DB::table('admins')
			->where('id', Input::get('id'))
			->update([
				'password' => $password
			]);
		}catch(Exception $e){

		}
	}

	public function addAdmins(){
		try{
			$password = Input::get('username');
            $password = Hash::make($password);
			DB::table('admins')->insert([
				'username' => Input::get('username'),
				'password' => $password,
				'position' => Input::get('position'),
				'email' => Input::get('username') . '@businesspartnersforum',
				'signature' => Input::get('signature'),
				'contract' => 'Untitled',
				'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
				]);
		}catch(Exception $e){

		}
	}

	public function deleteAdmins(){
		try{
			$id = Input::get('id');
			DB::table('admins')
			->where('id', $id)
			->delete();
		}catch(Exception $e){

		}
	}

	/*
	public function hashify(){
		try{
			$admin = DB::table('admins')->get();
			foreach($admin as $item){

				$pw = $item->password;
				$hashpw = Hash::make($pw);
				DB::table('admins')
				->where('id', $item->id)
				->update(['password' => $hashpw]);
			}

			echo 'complete';
		}catch(Exception $e){

		}
	}
	*/
}