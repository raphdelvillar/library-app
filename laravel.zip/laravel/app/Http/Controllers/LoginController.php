<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class LoginController extends BaseController
{

    public function doLogin(){
    	try{
            $array = array();
    		$username = Input::get('username');
    		$password = Input::get('password');

            //Admin
            $str = explode('/', $username);
            if($str[0] == 'Admin'){
                $user = DB::table('admins')->where('username', $str[1])->first();
                if(Hash::check($password, $user->password)){
                    $array['userID'] = $user->id;
                    $array['usertype'] = $user->position;
                    $array['username'] = $user->username;
                    $array['contract'] = $user->contract;
                    return json_encode($array);
                }
            }else{
        		$user = DB::table('users')->where('username', $username)->first();
        		if(Hash::check($password, $user->password)){
                    //Freelancer or Applicant
        			if($user->usertype == 'Freelancer' || $user->usertype == 'Applicant'){
                        /*
        				$service = DB::table('users')
        						   ->join('serviceproviders', 'users.infoID', '=', 'serviceproviders.id')
        						   ->where('users.username', $username)
        						   ->first();
                        */
                        $applicant = DB::table('applicants')
                                   ->where('id', $user->infoID)
                                   ->first();

                        $array['userID'] = $user->id;
                        $array['usertype'] = $user->usertype;
                        $array['username'] = $user->username;
        				return json_encode($array);
                    //Business Provider
        			}else if($user->usertype == 'Business Provider'){
                        /*
                        $business = DB::table('users')
                                    ->join('businessproviders', 'users.infoID', '=', 'businessproviders.id')
                                    ->where('users.username', $username)
                                    ->first();
                        */
                        $business = DB::table('businessproviders')
                                    ->where('id', $user->infoID)
                                    ->first();

                        $array['userID'] = $user->id;
                        $array['usertype'] = $user->usertype;
                        $array['username'] = $user->username;
                        return json_encode($array);
                    //Service Provider
        			}else if($user->usertype == 'Service Provider'){
                        $service = DB::table('serviceproviders')
                                   ->where('id', $user->infoID)
                                   ->first();

                        $array['userID'] = $user->id;
                        $array['usertype'] = $user->usertype;
                        $array['username'] - $user->username;
                        return json_encode($array);
                    }
        		}else{
        			$array['usertype'] == 'failure';
                    return json_encode($array);
        		}
            }
    	}catch(Exception $e){

    	}
    }

    public function checkEmail(){
        try {
            $email = Input::get('username');
            $users = DB::table('users')->where('username', $email)->first();
            if($users) {
                return 'failure';
            }else{
                return 'success';
            }

        }catch(Exception $e){

        }
    }
}
