<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EmailController; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class BulletinController extends BaseController
{

	public function getBulletin(){
		try{
            $filter = file_get_contents('php://input');
            $bulletin = DB::table('bulletins')
                    ->where('type', $filter)
                    ->orderBy('id', 'desc')
                    ->get();
            return json_encode($bulletin);
        }catch(Exception $e){

        }
	}

	public function deleteBulletin(){
		try{
			$id = Input::get('id');
			DB::table('bulletins')
			->where('id', $id)
			->delete();

		}catch(Exception $e){

		}
	}

	private function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function uploadBulletinPhoto(Request $request){
        try{
            $dir = __DIR__ . '/../../../uploads/bulletin/photo';
            $rand = $this->generateRandomString();
            $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            while(file_exists($dir . $filename)){
                $rand = $this->generateRandomString();
                $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            }

            $request->file('file')->move($dir, $filename);

            $url = url('/') . '/../uploads/bulletin/photo/';
            return $url . $filename;  
        }catch(Exception $e){

        }
    }

    public function addBulletin(){
    	try{
    		DB::table('bulletins')->insert([
                'title' => Input::get('title'),
                'content' => Input::get('content'),
                'src' => Input::get('src'),
                'starred' => Input::get('starred'),
                'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
        	]);
    	}catch(Exception $e){

    	}
    }

    public function updateBulletin(){
    	try{
    		$src = Input::get('src');
    		if($src == ''){
    			DB::table('bulletins')
				->where('id', Input::get('id'))
				->update([
					'title' => Input::get('title'), 
					'content' => Input::get('content'), 
					'starred' => Input::get('starred'),
					'updated_at' => DB::raw('now()')
				]);
    		}else{
    			DB::table('bulletins')
				->where('id', Input::get('id'))
				->update([
					'title' => Input::get('title'), 
					'content' => Input::get('content'),
					'src' => $src,
					'starred' => Input::get('starred'),
					'updated_at' => DB::raw('now()')
				]);
    		}
    	}catch(Exception $e){
    		
    	}

    }
}