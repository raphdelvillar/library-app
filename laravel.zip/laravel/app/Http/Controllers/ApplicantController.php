<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EmailController; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class ApplicantController extends BaseController
{

    /*Applicant / Freelancer Registration*/
    public function registerApplicant(){
        try{
            $email = Input::get('username');
            $name = Input::get('name');

        	DB::table('applicants')->insert([
                'name' => Input::get('name'),
                'title' => Input::get('title'),
                'position' => Input::get('position'),
                'others' => Input::get('others'),
                'ba' => Input::get('ba'),
                'bio' => Input::get('bio'),
                'nationality' => Input::get('nationality'),
                'mobile' => Input::get('mobile'),
                'email' => Input::get('username'),
                'cv' => Input::get('cv'),
                'photo' => Input::get('photo'),
                'referral' => Input::get('referral'),
                'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
        	]);

            $id = DB::getPdo()->lastInsertId();
            $password = Input::get('password');
            $password = Hash::make($password);
            DB::table('users')->insert([
                'username' => Input::get('username'),
                'password' => $password,
                'usertype' => Input::get('type'),
                'infoID' => $id,
                'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
            ]);

            $sendmail = new EmailController;
            $subject = '[Business Partners Forum] Welcome to Business Partners Forum!';
            $sendmail->sendmail('applicant', $name, $email, 'jobs@businesspartnersforum.com', 'Business Partners Forum', $subject, '');

        }catch(Exception $e){

        }
    }

    public function registerApplicant_UploadCV(Request $request){
        try{
            //var_dump($request->file('file')->getClientOriginalName()); 
            $dir = __DIR__ . '/../../../uploads/service_providers/resume';
            $rand = $this->generateRandomString();
            $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            while(file_exists($dir . $filename)){
                $rand = $this->generateRandomString();
                $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            }

            $request->file('file')->move($dir, $filename);

            $url = url('/') . '/../uploads/service_providers/resume/';
            return $url . $filename;   
        }catch(Exception $e){

        }
    }

    private function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public function registerApplicant_UploadPhoto(Request $request){
        try{
            $dir = __DIR__ . '/../../../uploads/service_providers/photo';
            $rand = $this->generateRandomString();
            $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            while(file_exists($dir . $filename)){
                $rand = $this->generateRandomString();
                $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            }

            $request->file('file')->move($dir, $filename);

            $url = url('/') . '/../uploads/service_providers/photo/';
            return $url . $filename;  
        }catch(Exception $e){

        }
    }

    /* Contact Applicant */
    public function contactApplicants(){
        try{
            $admin = DB::table('admins')
                     ->where('id', Input::get('id'))
                     ->first();

            $array = array();
            $array['name'] = Input::get('name');
            $array['emailto'] = Input::get('emailto');
            $array['email'] = $admin->email;
            $array['emailfromname'] = $admin->username;
            $array['subject'] = '[Business Partners Forum]' . Input::get('subject');
            $array['content'] = Input::get('content');
            $array['signature'] = $admin->signature;

            $sendmail = new EmailController;
            $sendmail->contactmail($array);
        }catch(Exception $e){

        }
    }

    /* Get Applicant */
    public function getApplicants(){
        try{
            $applicants = DB::table('users')
                               ->join('applicants', 'users.infoID', '=', 'applicants.id')
                               ->where('users.usertype','=', 'Applicant')
                               ->get();

            return json_encode($applicants);
        }catch(Exception $e){

        }
    }

    /* Get Freelancers */
    public function getFreelancers(){
        try{
            $freelancers = DB::table('users')
                               ->join('applicants', 'users.infoID', '=', 'applicants.id')
                               ->where('users.usertype','=', 'Freelancer')
                               ->get();

            return json_encode($freelancers);
        }catch(Exception $e){

        }
    }
}
