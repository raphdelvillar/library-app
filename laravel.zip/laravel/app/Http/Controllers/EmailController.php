<?php

namespace App\Http\Controllers;
use Mail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class EmailController extends BaseController
{
	public function sendmail($type, $name, $emailto, $emailfrom, $emailfromname, $subject, $content){

	    Mail::send($type,['name' => $name, 'content' => $content], function($message) use ($emailto, $subject, $emailfrom, $emailfromname){
	    	$message->from($emailfrom, $emailfromname);
	        $message->to($emailto);
	        $message->subject($subject);
	    });
    }

    public function contactmail($array){

    	Mail::send('contact', ['name' => $array['name'], 'content' => $array['content'], 'signature' => $array['signature']], function($message) use($array){
    		$message->from($array['emailto'], $array['emailfromname']);
    		$message->to($array['emailto']);
    		$message->subject($array['subject']);
    	});
    }
}