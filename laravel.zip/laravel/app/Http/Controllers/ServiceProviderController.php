<?php

namespace App\Http\Controllers;

use App\Http\Controllers\EmailController; 

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

use DB;

class ServiceProviderController extends BaseController
{

	/*Service Provider Registration*/
	public function registerServiceProvider(){
		try{
			DB::table('serviceproviders')->insert([
				'name' => Input::get('name'),
				'country' => Input::get('country'),
				'sector' => Input::get('sector'),
				'others' => Input::get('others'),
				'bio' => Input::get('bio'),
				'landline' => Input::get('landline'),
				'mobile' => Input::get('mobile'),
				'website' => Input::get('website'),
				'contact' => Input::get('contact'),
				'brochure' => Input::get('brochure'),
				'photo' => Input::get('photo'),
				'referral' => Input::get('referral'),
				'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
			]);

			$id = DB::getPdo()->lastInsertId();
			$password = Input::get('password');
			$password = Hash::make($password);
			DB::table('users')->insert([
				'username' => Input::get('username'),
				'password' => $password,
				'usertype' => Input::get('type'),
				'infoID' => $id,
				'created_at' => DB::raw('now()'),
                'updated_at' => DB::raw('now()')
			]);

			$sendmail = new EmailController;
            $subject = '[Business Partners Forum] Welcome to Business Partners Forum!';
            $sendmail->sendmail('service', $name, $email, 'info@businesspartnersforum.com', 'Business Partners Forum', $subject, '');

		}catch(Exception $e){

		}
	}

	public function registerServiceProvider_UploadPhoto(Request $request){
        try{
            //var_dump($request->file('file')->getClientOriginalName()); 
            $dir = __DIR__ . '/../../../employers/service_providers/photo';
            $rand = $this->generateRandomString();
            $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            while(file_exists($dir . $filename)){
                $rand = $this->generateRandomString();
                $filename = $rand . '_' . $request->file('file')->getClientOriginalName();
            }

            $request->file('file')->move($dir, $filename);

            $url = url('/') . '/../uploads/employers/service_providers/photo/';
            return $url . $filename;   
        }catch(Exception $e){

        }
    }

	public function registerServiceProvider_UploadBrochure(Request $request){
		try{
			$dir = __DIR__ . '/../../../uploads/employers/service_providers/brochure';
			$rand = $this->generateRandomString();
			$filename = $rand . '_' . $request->file('file')->getClientOriginalName();
			while(file_exists($dir . $filename)){
				$rand = $this->generateRandomString();
				$filename = $rand . '_' . $request->file('file')->getClientOriginalName();
			}

			$request->file('file')->move($dir, $filename);

			$url = url('/') . '/../uploads/employers/service_providers/brochure/';
			return $url. $filename;
		}catch(Exception $e){

		}
	}

	private function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    /* Get Service Provider */
    public function getServiceProviders(){
    	try{
    		$serviceproviders = DB::table('users')
    							->join('serviceproviders','users.infoID','=','serviceproviders.id')
    							->where('users.usertype','=', 'Service Provider')
    							->get();

    		return json_encode($serviceproviders);
    	}catch(Exception $e){

    	}
    }

    /* Contact Service Provider */
    public function contactServiceProvider(){
        try{
            $admin = DB::table('admins')
                     ->where('id', Input::get('id'))
                     ->first();

            $array = array();
            $array['name'] = Input::get('name');
            $array['emailto'] = Input::get('emailto');
            $array['email'] = $admin->email;
            $array['emailfromname'] = $admin->username;
            $array['subject'] = '[Business Partners Forum]' . Input::get('subject');
            $array['content'] = Input::get('content');
            $array['signature'] = $admin->signature;

            $sendmail = new EmailController;
            $sendmail->contactmail($array);
        }catch(Exception $e){

        }
    }

	/* select joborder */
	/*
	public function serviceproviderjoborder(){
		try{
			$array = array();
			$joborder = DB::table('jobs')->get();
			foreach($joborder as $job){
				$users = DB::table('users')
						 ->where('id', '=', $job->userID)
						 ->first();
				$business = DB::table('businessproviders')
							->where('id', '=', $users->infoID)
							->first();

				$ar['jobID'] = $job->id;
				$ar['position'] = $job->position;
				$ar['category'] = $job->category;
				$ar['category_others'] = $job->others;
				$ar['description'] = $job->description;
				$ar['name'] = $business->name;
				$ar['type'] = $business->type;
				$ar['country'] = $business->country;
				$ar['website'] = $business->website;
				$ar['mobile'] = $business->mobile;
				$ar['email'] = $business->email;
				$ar['sector'] = $business->sector;
				$ar['others'] = $business->others;
				$ar['brochure'] = $business->brochure;

				array_push($array, $ar);
			}

			return json_encode($array);
		}catch(Exception $e){

		}
	}
	*/
}